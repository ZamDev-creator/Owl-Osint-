#!/usr/bin/env python3
"""
Quick Patch untuk Event Loop Issue
Jalankan script ini untuk memperbaiki event loop error
"""

import sys
from pathlib import Path

def apply_patch():
    """Apply patch to main.py"""
    
    main_file = Path(__file__).parent / "main.py"
    
    if not main_file.exists():
        print("❌ Error: main.py tidak ditemukan!")
        return False
    
    print("🔧 Applying event loop patch...")
    
    with open(main_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if already patched
    if "nest_asyncio" in content:
        print("✅ Patch sudah diterapkan sebelumnya!")
        return True
    
    # Add import at the top
    import_section = """import asyncio
import sys
from pathlib import Path
from typing import Optional"""
    
    new_import = """import asyncio
import sys
from pathlib import Path
from typing import Optional

# Fix for event loop conflicts
try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    pass  # nest_asyncio not installed, will use fallback method"""
    
    content = content.replace(import_section, new_import)
    
    # Write back
    with open(main_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Patch berhasil diterapkan!")
    print("\n📦 Jangan lupa install nest_asyncio:")
    print("   pip install nest-asyncio")
    print("\nAtau aplikasi akan otomatis menggunakan fallback method.")
    
    return True

if __name__ == "__main__":
    success = apply_patch()
    sys.exit(0 if success else 1)
