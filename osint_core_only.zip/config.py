"""
Configuration file for OSINT Suite
Contains all settings, paths, and constants
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ============================================================================
# BASE PATHS
# ============================================================================

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
REPORTS_DIR = OUTPUT_DIR / "reports"
SCREENSHOTS_DIR = OUTPUT_DIR / "screenshots"
LOGS_DIR = OUTPUT_DIR / "logs"

# Create directories if they don't exist
for directory in [DATA_DIR, OUTPUT_DIR, REPORTS_DIR, SCREENSHOTS_DIR, LOGS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# ============================================================================
# API KEYS (Optional - from environment variables)
# ============================================================================

HIBP_API_KEY = os.getenv("HIBP_API_KEY", "")  # Have I Been Pwned
HUNTER_IO_KEY = os.getenv("HUNTER_IO_KEY", "")  # Hunter.io for email verification

# ============================================================================
# DATABASE
# ============================================================================

DB_PATH = BASE_DIR / "osint_data.db"

# ============================================================================
# NETWORK SETTINGS
# ============================================================================

MAX_WORKERS = 10  # For concurrent requests
REQUEST_TIMEOUT = 10  # seconds
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# ============================================================================
# EMAIL VALIDATION
# ============================================================================

EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

# ============================================================================
# CHANGE MONITOR SETTINGS
# ============================================================================

MONITOR_INTERVAL = 300  # seconds (5 minutes)
MAX_CONTENT_SIZE = 5 * 1024 * 1024  # 5MB

# ============================================================================
# LOGGING SETTINGS
# ============================================================================

LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
