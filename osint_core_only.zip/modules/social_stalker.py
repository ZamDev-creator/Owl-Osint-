#!/usr/bin/env python3
"""
Social Media Stalking Module - Enhanced Version
Fixed extraction methods for TikTok and Instagram profiles
"""

import requests
import re
import json
import time
import random
from typing import Dict, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


class SocialMediaStalker:
    """Professional social media scraper - Enhanced version"""
    
    def __init__(self):
        self.session = requests.Session()
        
        self.base_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0',
        }
        
        self.last_request = 0
        self.min_delay = 2
    
    def _wait(self):
        """Rate limiting with random jitter"""
        elapsed = time.time() - self.last_request
        if elapsed < self.min_delay:
            wait = self.min_delay - elapsed + random.uniform(0.5, 1.5)
            time.sleep(wait)
        self.last_request = time.time()
    
    def stalk_tiktok(self, username: str) -> Dict:
        """
        TikTok profile scraper with 6 enhanced extraction methods
        """
        result = {
            'platform': 'tiktok',
            'username': username,
            'success': False
        }
        
        try:
            clean = username.replace('@', '').strip()
            logger.info(f"TikTok scraping: @{clean}")
            print(f"  🔍 Loading TikTok page...")
            
            self._wait()
            
            url = f'https://www.tiktok.com/@{clean}'
            headers = self.base_headers.copy()
            headers['Referer'] = 'https://www.tiktok.com/'
            
            resp = self.session.get(url, headers=headers, timeout=30, allow_redirects=True)
            
            if resp.status_code != 200:
                result['error'] = f'HTTP {resp.status_code}'
                logger.error(f"TikTok HTTP error: {resp.status_code}")
                return result
            
            html = resp.text
            print(f"  📄 Extracting data... (trying 6 methods)")
            
            # METHOD 1: __UNIVERSAL_DATA_FOR_REHYDRATION__
            print(f"  🔍 Method 1: UNIVERSAL_DATA...")
            match = re.search(
                r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">(.*?)</script>',
                html,
                re.DOTALL
            )
            
            if match:
                try:
                    data = json.loads(match.group(1))
                    user = None
                    
                    # Try multiple paths
                    paths = [
                        lambda d: d['__DEFAULT_SCOPE__']['webapp.user-detail']['userInfo'],
                        lambda d: d['__DEFAULT_SCOPE__']['webapp.user-detail']['user'],
                        lambda d: d['__DEFAULT_SCOPE__']['webapp.user-detail']['userInfo']['user'],
                    ]
                    
                    for path_func in paths:
                        try:
                            user = path_func(data)
                            if user and isinstance(user, dict):
                                break
                        except:
                            continue
                    
                    if user and isinstance(user, dict):
                        stats = user.get('stats', {}) or user.get('statsV2', {}) or {}
                        
                        result['success'] = True
                        result['profile'] = {
                            'username': user.get('uniqueId', clean),
                            'nickname': user.get('nickname', 'N/A'),
                            'bio': (user.get('signature') or 'No bio')[:300],
                            'verified': bool(user.get('verified')),
                            'private': bool(user.get('privateAccount')),
                            'followers': stats.get('followerCount', user.get('followerCount', 'N/A')),
                            'following': stats.get('followingCount', user.get('followingCount', 'N/A')),
                            'total_likes': stats.get('heartCount', user.get('heartCount', 'N/A')),
                            'total_videos': stats.get('videoCount', user.get('videoCount', 'N/A')),
                            'avatar': user.get('avatarLarger') or user.get('avatarMedium', ''),
                            'profile_url': f'https://www.tiktok.com/@{clean}',
                        }
                        
                        logger.info(f"✅ TikTok Method 1 success")
                        print(f"  ✅ Method 1 successful!")
                        return result
                except Exception as e:
                    logger.debug(f"Method 1 failed: {e}")
                    print(f"  ✗ Method 1 failed")
            
            # METHOD 2: SIGI_STATE
            print(f"  🔍 Method 2: SIGI_STATE...")
            match = re.search(
                r'<script id="SIGI_STATE" type="application/json">(.*?)</script>',
                html,
                re.DOTALL
            )
            
            if match:
                try:
                    data = json.loads(match.group(1))
                    user = None
                    
                    # Try UserModule
                    try:
                        users = data.get('UserModule', {}).get('users', {})
                        if users:
                            user = list(users.values())[0]
                    except:
                        pass
                    
                    # Try UserPage
                    if not user:
                        try:
                            user = data.get('UserPage', {}).get('user')
                        except:
                            pass
                    
                    if user and isinstance(user, dict):
                        stats = user.get('stats', {}) or user.get('statsV2', {}) or {}
                        
                        result['success'] = True
                        result['profile'] = {
                            'username': user.get('uniqueId', clean),
                            'nickname': user.get('nickname', 'N/A'),
                            'bio': (user.get('signature') or 'No bio')[:300],
                            'verified': bool(user.get('verified')),
                            'private': bool(user.get('privateAccount')),
                            'followers': stats.get('followerCount', user.get('followerCount', 'N/A')),
                            'following': stats.get('followingCount', user.get('followingCount', 'N/A')),
                            'total_likes': stats.get('heartCount', user.get('heartCount', 'N/A')),
                            'total_videos': stats.get('videoCount', user.get('videoCount', 'N/A')),
                            'avatar': user.get('avatarLarger') or user.get('avatarMedium', ''),
                            'profile_url': f'https://www.tiktok.com/@{clean}',
                        }
                        
                        logger.info(f"✅ TikTok Method 2 success")
                        print(f"  ✅ Method 2 successful!")
                        return result
                except Exception as e:
                    logger.debug(f"Method 2 failed: {e}")
                    print(f"  ✗ Method 2 failed")
            
            # METHOD 3: Search all script tags for JSON with user data
            print(f"  🔍 Method 3: All JSON scripts...")
            all_scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
            
            for script in all_scripts:
                if '"uniqueId"' in script or '"followerCount"' in script:
                    try:
                        # Find JSON objects with uniqueId
                        json_matches = re.findall(r'\{[^{}]*"uniqueId"[^{}]*\}', script)
                        for json_str in json_matches:
                            try:
                                # Expand to get full object
                                start = script.find(json_str)
                                if start != -1:
                                    depth = 0
                                    full_json = ""
                                    for char in script[start:]:
                                        full_json += char
                                        if char == '{':
                                            depth += 1
                                        elif char == '}':
                                            depth -= 1
                                            if depth == 0:
                                                break
                                    
                                    user = json.loads(full_json)
                                    if isinstance(user, dict) and user.get('uniqueId'):
                                        stats = user.get('stats', {}) or user.get('statsV2', {}) or {}
                                        
                                        result['success'] = True
                                        result['profile'] = {
                                            'username': user.get('uniqueId', clean),
                                            'nickname': user.get('nickname', 'N/A'),
                                            'bio': (user.get('signature') or 'No bio')[:300],
                                            'verified': bool(user.get('verified')),
                                            'private': bool(user.get('privateAccount')),
                                            'followers': stats.get('followerCount', user.get('followerCount', 'N/A')),
                                            'following': stats.get('followingCount', user.get('followingCount', 'N/A')),
                                            'total_likes': stats.get('heartCount', user.get('heartCount', 'N/A')),
                                            'total_videos': stats.get('videoCount', user.get('videoCount', 'N/A')),
                                            'avatar': user.get('avatarLarger') or user.get('avatarMedium', ''),
                                            'profile_url': f'https://www.tiktok.com/@{clean}',
                                        }
                                        
                                        logger.info(f"✅ TikTok Method 3 success")
                                        print(f"  ✅ Method 3 successful!")
                                        return result
                            except:
                                continue
                    except:
                        continue
            
            print(f"  ✗ Method 3 failed")
            
            # METHOD 4: Enhanced regex from visible HTML and JSON fragments
            print(f"  🔍 Method 4: Enhanced regex...")
            
            followers = following = likes = videos = None
            nickname = bio = None
            
            # Try multiple patterns for each field
            follower_patterns = [
                r'"followerCount":\s*(\d+)',
                r'follower[Cc]ount["\']?\s*:\s*(\d+)',
                r'"followers":\s*(\d+)',
                r'(\d+\.?\d*[KMB]?)\s+[Ff]ollowers',
            ]
            for p in follower_patterns:
                m = re.search(p, html)
                if m:
                    followers = m.group(1)
                    break
            
            following_patterns = [
                r'"followingCount":\s*(\d+)',
                r'following[Cc]ount["\']?\s*:\s*(\d+)',
                r'(\d+\.?\d*[KMB]?)\s+[Ff]ollowing',
            ]
            for p in following_patterns:
                m = re.search(p, html)
                if m:
                    following = m.group(1)
                    break
            
            likes_patterns = [
                r'"heartCount":\s*(\d+)',
                r'"heart":\s*(\d+)',
                r'"diggCount":\s*(\d+)',
                r'(\d+\.?\d*[KMB]?)\s+[Ll]ikes',
            ]
            for p in likes_patterns:
                m = re.search(p, html)
                if m:
                    likes = m.group(1)
                    break
            
            videos_patterns = [
                r'"videoCount":\s*(\d+)',
                r'video[Cc]ount["\']?\s*:\s*(\d+)',
            ]
            for p in videos_patterns:
                m = re.search(p, html)
                if m:
                    videos = m.group(1)
                    break
            
            # Nickname from title
            m = re.search(r'<title>([^(@<]+)', html)
            if m:
                nickname = m.group(1).strip()
            
            # Bio from meta
            m = re.search(r'<meta[^>]*property="og:description"[^>]*content="([^"]+)', html)
            if m:
                bio = m.group(1)
            
            if followers or nickname:
                result['success'] = True
                result['profile'] = {
                    'username': clean,
                    'nickname': nickname or 'N/A',
                    'bio': bio or 'No bio',
                    'verified': False,
                    'private': False,
                    'followers': followers or 'N/A',
                    'following': following or 'N/A',
                    'total_likes': likes or 'N/A',
                    'total_videos': videos or 'N/A',
                    'avatar': '',
                    'profile_url': f'https://www.tiktok.com/@{clean}',
                }
                result['profile']['note'] = '⚠️ Partial data extracted from HTML'
                
                logger.info(f"✅ TikTok Method 4 success")
                print(f"  ✅ Method 4 successful!")
                return result
            
            print(f"  ✗ Method 4 failed")
            
            # METHOD 5: Profile existence check
            print(f"  🔍 Method 5: Profile existence...")
            
            # Check for patterns that confirm profile exists
            exists_patterns = [
                r'<meta[^>]*property="og:url"[^>]*content="https://www\.tiktok\.com/@' + re.escape(clean),
                r'<link[^>]*rel="canonical"[^>]*href="https://www\.tiktok\.com/@' + re.escape(clean),
                r'<title>[^<]*@?' + re.escape(clean),
                r'"uniqueId"\s*:\s*"' + re.escape(clean) + '"',
            ]
            
            profile_exists = any(re.search(pattern, html, re.IGNORECASE) for pattern in exists_patterns)
            
            # Also check for "user not found" or similar error messages
            error_patterns = [
                r'user\s+not\s+found',
                r'account\s+not\s+found',
                r'this\s+account\s+doesn',
            ]
            has_error = any(re.search(pattern, html, re.IGNORECASE) for pattern in error_patterns)
            
            if profile_exists and not has_error:
                title = re.search(r'<title>([^<]+)', html)
                desc = re.search(r'<meta[^>]*name="description"[^>]*content="([^"]+)', html)
                
                result['success'] = True
                result['profile'] = {
                    'username': clean,
                    'nickname': title.group(1).strip() if title else clean,
                    'bio': desc.group(1)[:300] if desc else 'Profile exists',
                    'verified': False,
                    'private': False,
                    'followers': 'N/A',
                    'following': 'N/A',
                    'total_likes': 'N/A',
                    'total_videos': 'N/A',
                    'avatar': '',
                    'profile_url': f'https://www.tiktok.com/@{clean}',
                }
                result['profile']['note'] = '⚠️ Profile confirmed to exist but stats unavailable - may be private or restricted'
                
                logger.info(f"✅ TikTok Method 5 success")
                print(f"  ✅ Method 5 successful (limited data)")
                return result
            
            print(f"  ✗ Method 5 failed")
            
            # METHOD 6: Try OEmbed API as last resort
            print(f"  🔍 Method 6: OEmbed API...")
            try:
                oembed_url = f"https://www.tiktok.com/oembed?url=https://www.tiktok.com/@{clean}"
                resp_oembed = self.session.get(oembed_url, headers=headers, timeout=15)
                
                if resp_oembed.status_code == 200:
                    oembed_data = resp_oembed.json()
                    if oembed_data.get('author_name'):
                        result['success'] = True
                        result['profile'] = {
                            'username': clean,
                            'nickname': oembed_data.get('author_name', 'N/A'),
                            'bio': 'Profile exists - limited data available',
                            'verified': False,
                            'private': False,
                            'followers': 'N/A',
                            'following': 'N/A',
                            'total_likes': 'N/A',
                            'total_videos': 'N/A',
                            'avatar': oembed_data.get('thumbnail_url', ''),
                            'profile_url': f'https://www.tiktok.com/@{clean}',
                        }
                        result['profile']['note'] = '⚠️ Limited data - extracted via OEmbed API'
                        
                        logger.info(f"✅ TikTok Method 6 success")
                        print(f"  ✅ Method 6 successful (limited data)!")
                        return result
            except Exception as e:
                logger.debug(f"Method 6 failed: {e}")
                print(f"  ✗ Method 6 failed")
            
            print(f"  ✗ All methods failed")
            result['error'] = 'Could not extract profile data - profile may not exist, be private, or TikTok changed their page structure'
        
        except requests.Timeout:
            result['error'] = 'Request timeout - TikTok server took too long to respond'
            logger.error(f"Timeout on TikTok")
        except requests.ConnectionError:
            result['error'] = 'Connection error - unable to reach TikTok'
            logger.error(f"Connection error")
        except Exception as e:
            result['error'] = f'Error: {str(e)}'
            logger.error(f"TikTok error: {e}", exc_info=True)
        
        return result
    
    def stalk_instagram(self, username: str) -> Dict:
        """
        Instagram profile scraper with 5 enhanced extraction methods
        """
        result = {
            'platform': 'instagram',
            'username': username,
            'success': False
        }
        
        try:
            clean = username.replace('@', '').strip()
            logger.info(f"Instagram scraping: @{clean}")
            print(f"  🔍 Loading Instagram page...")
            
            self._wait()
            
            url = f'https://www.instagram.com/{clean}/'
            headers = self.base_headers.copy()
            headers['Referer'] = 'https://www.instagram.com/'
            
            resp = self.session.get(url, headers=headers, timeout=30, allow_redirects=True)
            
            if resp.status_code == 404:
                result['error'] = 'Profile not found (404)'
                return result
            
            if resp.status_code != 200:
                result['error'] = f'HTTP {resp.status_code}'
                return result
            
            html = resp.text
            print(f"  📄 Extracting data... (trying 5 methods)")
            
            # METHOD 1: window._sharedData
            print(f"  🔍 Method 1: _sharedData...")
            match = re.search(r'window\._sharedData\s*=\s*({.*?});</script>', html, re.DOTALL)
            
            if match:
                try:
                    data = json.loads(match.group(1))
                    user = None
                    
                    # Try path 1
                    try:
                        user = data['entry_data']['ProfilePage'][0]['graphql']['user']
                    except:
                        pass
                    
                    # Try path 2
                    if not user:
                        try:
                            user = data['entry_data']['ProfilePage'][0]['user']
                        except:
                            pass
                    
                    if user and isinstance(user, dict):
                        result['success'] = True
                        result['profile'] = {
                            'username': user.get('username', clean),
                            'full_name': user.get('full_name', 'N/A'),
                            'bio': (user.get('biography') or 'No bio')[:300],
                            'verified': bool(user.get('is_verified')),
                            'private': bool(user.get('is_private')),
                            'followers': user.get('edge_followed_by', {}).get('count', 'N/A'),
                            'following': user.get('edge_follow', {}).get('count', 'N/A'),
                            'posts': user.get('edge_owner_to_timeline_media', {}).get('count', 'N/A'),
                            'profile_pic': user.get('profile_pic_url', ''),
                            'profile_pic_hd': user.get('profile_pic_url_hd', ''),
                            'external_url': user.get('external_url', ''),
                            'profile_url': f'https://www.instagram.com/{clean}/',
                        }
                        
                        if user.get('is_business_account'):
                            result['profile']['business_account'] = True
                            result['profile']['category'] = user.get('category_name', 'N/A')
                        
                        logger.info(f"✅ Instagram Method 1 success")
                        print(f"  ✅ Method 1 successful!")
                        return result
                except Exception as e:
                    logger.debug(f"Method 1 failed: {e}")
                    print(f"  ✗ Method 1 failed")
            
            # METHOD 2: Search all script tags for JSON
            print(f"  🔍 Method 2: All JSON scripts...")
            all_scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
            
            for script in all_scripts:
                if '"edge_followed_by"' in script or '"username"' in script:
                    try:
                        # Look for edge_followed_by pattern
                        match = re.search(r'"edge_followed_by":\s*\{\s*"count":\s*(\d+)\s*\}', script)
                        if match:
                            followers = match.group(1)
                            
                            # Get other stats
                            following_m = re.search(r'"edge_follow":\s*\{\s*"count":\s*(\d+)\s*\}', script)
                            posts_m = re.search(r'"edge_owner_to_timeline_media":\s*\{\s*"count":\s*(\d+)\s*\}', script)
                            
                            name_m = re.search(r'"full_name":\s*"([^"]*)"', script)
                            bio_m = re.search(r'"biography":\s*"([^"]*)"', script)
                            verified_m = re.search(r'"is_verified":\s*(true|false)', script)
                            private_m = re.search(r'"is_private":\s*(true|false)', script)
                            
                            result['success'] = True
                            result['profile'] = {
                                'username': clean,
                                'full_name': name_m.group(1) if name_m else 'N/A',
                                'bio': bio_m.group(1)[:300] if bio_m else 'No bio',
                                'verified': verified_m and verified_m.group(1) == 'true',
                                'private': private_m and private_m.group(1) == 'true',
                                'followers': followers,
                                'following': following_m.group(1) if following_m else 'N/A',
                                'posts': posts_m.group(1) if posts_m else 'N/A',
                                'profile_pic': '',
                                'profile_pic_hd': '',
                                'external_url': '',
                                'profile_url': f'https://www.instagram.com/{clean}/',
                            }
                            
                            logger.info(f"✅ Instagram Method 2 success")
                            print(f"  ✅ Method 2 successful!")
                            return result
                    except:
                        continue
            
            print(f"  ✗ Method 2 failed")
            
            # METHOD 3: Regex from visible HTML
            print(f"  🔍 Method 3: HTML regex...")
            
            # Extract from meta and visible text
            followers = re.search(r'(\d{1,3}(?:,\d{3})*(?:\.\d+)?[KMB]?)\s+[Ff]ollowers', html)
            following = re.search(r'(\d{1,3}(?:,\d{3})*(?:\.\d+)?[KMB]?)\s+[Ff]ollowing', html)
            posts = re.search(r'(\d{1,3}(?:,\d{3})*(?:\.\d+)?[KMB]?)\s+[Pp]osts', html)
            
            name = re.search(r'<meta[^>]*property="og:title"[^>]*content="([^"]+)', html)
            desc = re.search(r'<meta[^>]*property="og:description"[^>]*content="([^"]+)', html)
            
            if followers or name:
                full_name = 'N/A'
                if name:
                    full_name = name.group(1).strip()
                    if ' (@' in full_name:
                        full_name = full_name.split(' (@')[0]
                
                result['success'] = True
                result['profile'] = {
                    'username': clean,
                    'full_name': full_name,
                    'bio': desc.group(1)[:300] if desc else 'No bio',
                    'verified': False,
                    'private': False,
                    'followers': followers.group(1) if followers else 'N/A',
                    'following': following.group(1) if following else 'N/A',
                    'posts': posts.group(1) if posts else 'N/A',
                    'profile_pic': '',
                    'profile_pic_hd': '',
                    'external_url': '',
                    'profile_url': f'https://www.instagram.com/{clean}/',
                }
                result['profile']['note'] = '⚠️ Partial data extracted from HTML'
                
                logger.info(f"✅ Instagram Method 3 success")
                print(f"  ✅ Method 3 successful!")
                return result
            
            print(f"  ✗ Method 3 failed")
            
            # METHOD 4: Profile existence check
            print(f"  🔍 Method 4: Profile existence...")
            
            # Check for patterns that confirm profile exists
            exists_patterns = [
                r'<meta[^>]*property="og:url"[^>]*content="https://www\.instagram\.com/' + re.escape(clean),
                r'<link[^>]*rel="canonical"[^>]*href="https://www\.instagram\.com/' + re.escape(clean),
                r'"username"\s*:\s*"' + re.escape(clean) + '"',
            ]
            
            profile_exists = any(re.search(pattern, html, re.IGNORECASE) for pattern in exists_patterns)
            
            # Check for error messages
            error_patterns = [
                r'Sorry,\s+this\s+page',
                r'page\s+not\s+available',
            ]
            has_error = any(re.search(pattern, html, re.IGNORECASE) for pattern in error_patterns)
            
            if profile_exists and not has_error:
                title = re.search(r'<title>([^<]+)', html)
                result['success'] = True
                result['profile'] = {
                    'username': clean,
                    'full_name': title.group(1).strip()[:50] if title else 'N/A',
                    'bio': 'Profile exists',
                    'verified': False,
                    'private': False,
                    'followers': 'N/A',
                    'following': 'N/A',
                    'posts': 'N/A',
                    'profile_pic': '',
                    'profile_pic_hd': '',
                    'external_url': '',
                    'profile_url': f'https://www.instagram.com/{clean}/',
                }
                result['profile']['note'] = '⚠️ Profile confirmed to exist but stats unavailable - likely private or login required'
                
                logger.info(f"✅ Instagram Method 4 success")
                print(f"  ✅ Method 4 successful (limited data)")
                return result
            
            print(f"  ✗ Method 4 failed")
            
            # METHOD 5: Meta tags only (last resort)
            print(f"  🔍 Method 5: Meta tags only...")
            
            title = re.search(r'<title>([^<]+)', html)
            if title and clean.lower() in title.group(1).lower():
                result['success'] = True
                result['profile'] = {
                    'username': clean,
                    'full_name': title.group(1).strip()[:50],
                    'bio': 'Profile detected via meta tags',
                    'verified': False,
                    'private': False,
                    'followers': 'N/A',
                    'following': 'N/A',
                    'posts': 'N/A',
                    'profile_pic': '',
                    'profile_pic_hd': '',
                    'external_url': '',
                    'profile_url': f'https://www.instagram.com/{clean}/',
                }
                result['profile']['note'] = '⚠️ Minimal data - profile may exist but details unavailable'
                
                logger.info(f"✅ Instagram Method 5 success")
                print(f"  ✅ Method 5 successful (minimal data)")
                return result
            
            print(f"  ✗ All methods failed")
            result['error'] = 'Could not extract profile data - profile may not exist, be private, or Instagram changed their structure'
        
        except requests.Timeout:
            result['error'] = 'Request timeout'
        except Exception as e:
            result['error'] = f'Error: {str(e)}'
            logger.error(f"Instagram error: {e}", exc_info=True)
        
        return result
    
    def stalk_multi_platform(self, username: str) -> Dict:
        """Search both platforms"""
        result = {'username': username, 'platforms': {}}
        
        print(f"  🔍 Checking TikTok...")
        result['platforms']['tiktok'] = self.stalk_tiktok(username)
        
        print(f"  🔍 Checking Instagram...")
        result['platforms']['instagram'] = self.stalk_instagram(username)
        
        result['found_on'] = sum(1 for p in result['platforms'].values() if p.get('success'))
        result['total_checked'] = 2
        
        return result
    
    def compare_profiles(self, tt_user: str, ig_user: str) -> Dict:
        """Compare profiles"""
        result = {
            'comparison': {},
            'tiktok': self.stalk_tiktok(tt_user),
            'instagram': self.stalk_instagram(ig_user)
        }
        
        if result['tiktok'].get('success') and result['instagram'].get('success'):
            tt = result['tiktok']['profile']
            ig = result['instagram']['profile']
            
            def to_int(v):
                if not v or v == 'N/A':
                    return 0
                v = str(v).replace(',', '')
                try:
                    if 'K' in v:
                        return int(float(v.replace('K', '')) * 1000)
                    if 'M' in v:
                        return int(float(v.replace('M', '')) * 1000000)
                    if 'B' in v:
                        return int(float(v.replace('B', '')) * 1000000000)
                    return int(float(v))
                except:
                    return 0
            
            result['comparison'] = {
                'total_followers': {
                    'tiktok': to_int(tt.get('followers')),
                    'instagram': to_int(ig.get('followers')),
                    'difference': abs(to_int(tt.get('followers')) - to_int(ig.get('followers')))
                },
                'total_posts': {
                    'tiktok': to_int(tt.get('total_videos')),
                    'instagram': to_int(ig.get('posts')),
                    'difference': abs(to_int(tt.get('total_videos')) - to_int(ig.get('posts')))
                },
                'verified': {
                    'tiktok': tt.get('verified', False),
                    'instagram': ig.get('verified', False),
                    'both_verified': tt.get('verified') and ig.get('verified')
                }
            }
        
        return result
    
    def get_profile_summary(self, data: Dict) -> str:
        """Format for display"""
        if not data.get('success'):
            return f"❌ Error: {data.get('error', 'Unknown error')}"
        
        p = data['profile']
        platform = data['platform'].upper()
        
        def fmt(v):
            if not v or v == 'N/A':
                return 'N/A'
            try:
                if isinstance(v, str) and any(x in v for x in ['K', 'M', 'B']):
                    return v
                num = int(v)
                if num >= 1000000000:
                    return f"{num/1000000000:.1f}B"
                elif num >= 1000000:
                    return f"{num/1000000:.1f}M"
                elif num >= 1000:
                    return f"{num/1000:.1f}K"
                return f"{num:,}"
            except:
                return str(v)
        
        summary = f"""
✅ {platform} Profile Found
━━━━━━━━━━━━━━━━━━━━━━━━
👤 Username: @{p['username']}
📝 Name: {p.get('nickname') or p.get('full_name', 'N/A')}
📄 Bio: {p.get('bio', 'No bio')[:100]}
✓ Verified: {'Yes ✓' if p.get('verified') else 'No'}
🔒 Private: {'Yes 🔒' if p.get('private') else 'No'}

📊 Statistics:
  👥 Followers: {fmt(p.get('followers'))} 
  👤 Following: {fmt(p.get('following'))}
  📸 Posts/Videos: {fmt(p.get('total_videos') or p.get('posts'))}"""
        
        if p.get('total_likes') and p.get('total_likes') != 'N/A':
            summary += f"\n  ❤️ Total Likes: {fmt(p['total_likes'])}"
        
        summary += f"\n\n🔗 Profile: {p['profile_url']}"
        
        if p.get('note'):
            summary += f"\n\n{p['note']}"
        
        return summary + "\n"
