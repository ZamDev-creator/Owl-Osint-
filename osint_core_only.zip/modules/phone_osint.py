#!/usr/bin/env python3
"""
Phone Number OSINT Module
Analyze and gather information about phone numbers
"""

import re
import requests
from typing import Dict, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)

# Try to import phonenumbers library for better parsing
try:
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone
    PHONENUMBERS_AVAILABLE = True
except ImportError:
    PHONENUMBERS_AVAILABLE = False
    logger.warning("phonenumbers library not installed - using basic parsing")


class PhoneOSINT:
    """Phone number intelligence gathering with advanced features"""
    
    def __init__(self):
        self.api_base = "https://api.apilayer.com/number_verification/validate"
        # Free alternatives
        self.numverify_base = "http://apilayer.net/api/validate"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def validate_phone_number(self, phone: str) -> bool:
        """Validate phone number format"""
        # Remove non-numeric characters except +
        cleaned = re.sub(r'[^\d+]', '', phone)
        # Basic validation
        return len(cleaned) >= 10 and len(cleaned) <= 15
    
    def get_phone_info(self, phone_number: str) -> Dict:
        """
        Get comprehensive information about a phone number
        Uses phonenumbers library if available, otherwise fallback to basic parsing
        """
        if not self.validate_phone_number(phone_number):
            return {
                'valid': False,
                'error': 'Invalid phone number format'
            }
        
        # Clean the phone number
        cleaned_number = re.sub(r'[^\d+]', '', phone_number)
        
        result = {
            'number': cleaned_number,
            'valid': True,
            'info': {},
            'advanced_info': {},
            'social_media': {}
        }
        
        try:
            if PHONENUMBERS_AVAILABLE:
                # Use phonenumbers library for accurate parsing
                result = self._parse_with_phonenumbers(cleaned_number)
            else:
                # Fallback to basic parsing
                result['info']['country_code'] = self._extract_country_code(cleaned_number)
                result['info']['number_type'] = self._guess_number_type(cleaned_number)
                result['info']['carrier'] = self._lookup_carrier(cleaned_number)
                result['info']['location'] = self._estimate_location(cleaned_number)
                result['info']['formatted'] = self._format_number(cleaned_number)
            
            # Add social media links
            result['social_media'] = self.search_social_media(cleaned_number)
            
            # Try online validation APIs
            result['advanced_info'] = self._lookup_online(cleaned_number)
            
            logger.info(f"Phone lookup successful: {cleaned_number}")
            
        except Exception as e:
            logger.error(f"Error getting phone info: {e}")
            result['error'] = str(e)
        
        return result
    
    def _parse_with_phonenumbers(self, phone: str) -> Dict:
        """Parse phone number using phonenumbers library"""
        result = {
            'number': phone,
            'valid': False,
            'info': {},
            'advanced_info': {},
            'social_media': {}
        }
        
        try:
            # Try to parse the number
            # Default to ID region if no country code
            if not phone.startswith('+'):
                phone = '+62' + phone.lstrip('0')
            
            parsed = phonenumbers.parse(phone, None)
            
            # Validate
            result['valid'] = phonenumbers.is_valid_number(parsed)
            result['info']['is_possible'] = phonenumbers.is_possible_number(parsed)
            
            # Get country information
            result['info']['country_code'] = {
                'code': f'+{parsed.country_code}',
                'country': geocoder.description_for_number(parsed, 'en')
            }
            
            # Get carrier information
            carrier_name = carrier.name_for_number(parsed, 'en')
            result['info']['carrier'] = carrier_name if carrier_name else 'Unknown'
            
            # Get timezone
            timezones = timezone.time_zones_for_number(parsed)
            result['info']['timezones'] = list(timezones) if timezones else ['Unknown']
            
            # Get location
            location = geocoder.description_for_number(parsed, 'en')
            result['info']['location'] = location if location else 'Unknown'
            
            # Number type
            number_type = phonenumbers.number_type(parsed)
            type_map = {
                0: 'Fixed Line',
                1: 'Mobile',
                2: 'Fixed Line or Mobile',
                3: 'Toll Free',
                4: 'Premium Rate',
                5: 'Shared Cost',
                6: 'VoIP',
                7: 'Personal Number',
                8: 'Pager',
                9: 'UAN',
                10: 'Voicemail',
                27: 'Unknown'
            }
            result['info']['number_type'] = type_map.get(number_type, 'Unknown')
            
            # Formatted versions
            result['info']['formatted'] = {
                'international': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
                'national': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL),
                'e164': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164),
                'rfc3966': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.RFC3966)
            }
            
        except phonenumbers.NumberParseException as e:
            result['error'] = f'Parse error: {str(e)}'
            logger.error(f"Phone number parse error: {e}")
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Unexpected error in phone parsing: {e}")
        
        return result
    
    def _lookup_online(self, phone: str) -> Dict:
        """Lookup phone number using online APIs"""
        info = {}
        
        try:
            # Try NumVerify API (free tier available)
            # Note: This requires an API key, placeholder for now
            info['online_validation'] = 'Not configured - API key required'
            
            # Add HLR lookup placeholder
            info['hlr_lookup'] = 'Not available in free tier'
            
            # Spam/scam check placeholder
            info['spam_check'] = self._check_spam_databases(phone)
            
        except Exception as e:
            logger.error(f"Online lookup error: {e}")
            info['error'] = str(e)
        
        return info
    
    def _check_spam_databases(self, phone: str) -> Dict:
        """Check phone against known spam databases"""
        # This is a placeholder - in production you'd integrate with:
        # - WhoCallsMe API
        # - NumLookup
        # - Truecaller (requires auth)
        
        return {
            'checked': True,
            'databases': ['Local DB'],
            'is_spam': False,
            'reports': 0,
            'note': 'Spam checking requires API integration'
        }

    
    def _extract_country_code(self, phone: str) -> Dict:
        """Extract country code from phone number"""
        country_codes = {
            '1': 'US/Canada',
            '44': 'United Kingdom',
            '62': 'Indonesia',
            '91': 'India',
            '81': 'Japan',
            '86': 'China',
            '7': 'Russia',
            '33': 'France',
            '49': 'Germany',
            '39': 'Italy',
            '34': 'Spain',
            '55': 'Brazil',
            '61': 'Australia',
            '60': 'Malaysia',
            '65': 'Singapore',
            '66': 'Thailand',
            '84': 'Vietnam',
            '63': 'Philippines',
        }
        
        if phone.startswith('+'):
            for code, country in country_codes.items():
                if phone[1:].startswith(code):
                    return {
                        'code': f'+{code}',
                        'country': country
                    }
        
        # Default for Indonesia
        if len(phone) >= 10 and phone.startswith('0'):
            return {
                'code': '+62',
                'country': 'Indonesia'
            }
        
        return {
            'code': 'Unknown',
            'country': 'Unknown'
        }
    
    def _guess_number_type(self, phone: str) -> str:
        """Guess if mobile or landline based on patterns"""
        # Remove country code for analysis
        if phone.startswith('+62'):
            local = phone[3:]
        elif phone.startswith('0'):
            local = phone[1:]
        else:
            local = phone
        
        # Indonesian mobile prefixes
        mobile_prefixes = ['8', '81', '82', '83', '85', '87', '88', '89']
        
        for prefix in mobile_prefixes:
            if local.startswith(prefix):
                return 'Mobile'
        
        return 'Landline/Unknown'
    
    def _lookup_carrier(self, phone: str) -> str:
        """Lookup carrier/operator based on number prefix"""
        if phone.startswith('+62') or phone.startswith('0'):
            # Indonesian carriers
            carriers = {
                '811': 'Telkomsel (Halo)',
                '812': 'Telkomsel (simPATI)',
                '813': 'Telkomsel (simPATI)',
                '821': 'Telkomsel (simPATI)',
                '822': 'Telkomsel (simPATI)',
                '823': 'Telkomsel (simPATI)',
                '852': 'Telkomsel (AS)',
                '853': 'Telkomsel (AS)',
                '851': 'Telkomsel (AS)',
                '814': 'Indosat',
                '815': 'Indosat',
                '816': 'Indosat',
                '855': 'Indosat',
                '856': 'Indosat',
                '857': 'Indosat',
                '858': 'Indosat',
                '817': 'XL',
                '818': 'XL',
                '819': 'XL',
                '859': 'XL',
                '877': 'XL',
                '878': 'XL',
                '831': 'Axis',
                '832': 'Axis',
                '833': 'Axis',
                '838': 'Axis',
                '895': 'Three',
                '896': 'Three',
                '897': 'Three',
                '898': 'Three',
                '899': 'Three',
                '881': 'Smartfren',
                '882': 'Smartfren',
                '883': 'Smartfren',
                '884': 'Smartfren',
                '885': 'Smartfren',
                '886': 'Smartfren',
                '887': 'Smartfren',
                '888': 'Smartfren',
                '889': 'Smartfren',
            }
            
            local = phone.replace('+62', '').replace('0', '', 1)
            
            for prefix, carrier in carriers.items():
                if local.startswith(prefix):
                    return carrier
        
        return 'Unknown'
    
    def _estimate_location(self, phone: str) -> str:
        """Estimate location based on area code (for landlines)"""
        if phone.startswith('+62') or phone.startswith('0'):
            area_codes = {
                '21': 'Jakarta',
                '22': 'Bandung',
                '24': 'Semarang',
                '31': 'Surabaya',
                '61': 'Medan',
                '274': 'Yogyakarta',
                '341': 'Malang',
                '361': 'Denpasar',
                '411': 'Makassar',
            }
            
            local = phone.replace('+62', '').replace('0', '', 1)
            
            for code, city in area_codes.items():
                if local.startswith(code):
                    return f'{city}, Indonesia'
        
        return 'Unknown'
    
    def _format_number(self, phone: str) -> str:
        """Format phone number nicely"""
        if phone.startswith('+62'):
            # Indonesian format
            local = phone[3:]
            if len(local) >= 10:
                return f'+62 {local[:3]}-{local[3:7]}-{local[7:]}'
        elif phone.startswith('0'):
            if len(phone) >= 11:
                return f'{phone[:4]}-{phone[4:8]}-{phone[8:]}'
        
        return phone
    
    def search_social_media(self, phone: str) -> Dict:
        """Search for social media accounts linked to phone number"""
        clean_phone = phone.replace('+', '').replace('-', '').replace(' ', '')
        
        return {
            'whatsapp': {
                'url': f'https://wa.me/{clean_phone}',
                'check_url': f'https://api.whatsapp.com/send?phone={clean_phone}',
                'note': 'Click to verify if number is on WhatsApp'
            },
            'telegram': {
                'url': f'https://t.me/{clean_phone}',
                'note': 'Manual verification required'
            },
            'viber': {
                'url': f'viber://add?number={clean_phone}',
                'note': 'Requires Viber app'
            },
            'signal': {
                'note': 'Signal requires the app to check'
            },
            'facebook': {
                'search_url': f'https://www.facebook.com/search/top/?q={phone}',
                'note': 'Search Facebook for this number'
            },
            'note': 'Manual verification required for all platforms'
        }
    
    def generate_report_data(self, phone: str, results: Dict) -> Dict:
        """Generate formatted report data for phone OSINT"""
        report = {
            'phone_number': phone,
            'timestamp': logger.name,
            'validation': {
                'is_valid': results.get('valid', False),
                'is_possible': results.get('info', {}).get('is_possible', 'Unknown')
            },
            'details': results.get('info', {}),
            'advanced': results.get('advanced_info', {}),
            'social_media': results.get('social_media', {}),
            'recommendations': []
        }
        
        # Add recommendations
        if results.get('valid'):
            report['recommendations'].append('✅ Number appears to be valid')
        else:
            report['recommendations'].append('⚠️ Number validation failed')
        
        if results.get('advanced_info', {}).get('spam_check', {}).get('is_spam'):
            report['recommendations'].append('🚨 WARNING: Number reported as spam')
        
        return report

