"""
Image Metadata Module
Extract EXIF metadata from images including GPS, camera info, and timestamps
"""

from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS
from datetime import datetime
from pathlib import Path
import piexif
from utils.logger import setup_logger
from utils.database import Database

logger = setup_logger(__name__)


class ImageMetadata:
    """Extract and analyze image metadata"""
    
    def __init__(self):
        """Initialize image metadata extractor with database"""
        self.db = Database()
    
    def get_decimal_coordinates(self, gps_info):
        """
        Convert GPS coordinates to decimal format
        
        Args:
            gps_info: GPS information from EXIF
        
        Returns:
            tuple: (latitude, longitude) in decimal degrees
        """
        try:
            gps_latitude = gps_info.get('GPSLatitude')
            gps_latitude_ref = gps_info.get('GPSLatitudeRef')
            gps_longitude = gps_info.get('GPSLongitude')
            gps_longitude_ref = gps_info.get('GPSLongitudeRef')
            
            if gps_latitude and gps_latitude_ref and gps_longitude and gps_longitude_ref:
                lat = self._convert_to_degrees(gps_latitude)
                if gps_latitude_ref != 'N':
                    lat = -lat
                
                lon = self._convert_to_degrees(gps_longitude)
                if gps_longitude_ref != 'E':
                    lon = -lon
                
                return lat, lon
            return None, None
        except Exception as e:
            logger.error(f"Error converting GPS coordinates: {e}")
            return None, None
    
    def _convert_to_degrees(self, value):
        """
        Convert GPS coordinates to degrees
        
        Args:
            value: GPS coordinate value
        
        Returns:
            float: Coordinate in decimal degrees
        """
        try:
            d = float(value[0])
            m = float(value[1])
            s = float(value[2])
            return d + (m / 60.0) + (s / 3600.0)
        except Exception as e:
            logger.error(f"Error: {e}")
            # Sometimes coordinates are already in decimal
            return float(value[0])
    
    def extract_metadata(self, image_path):
        """
        Extract all available metadata from image
        
        Args:
            image_path: Path to image file
        
        Returns:
            dict: Dictionary containing all extracted metadata
        """
        logger.info(f"Extracting metadata from: {image_path}")
        
        metadata = {
            'filename': Path(image_path).name,
            'file_size': None,
            'dimensions': None,
            'format': None,
            'mode': None,
            'camera_make': None,
            'camera_model': None,
            'software': None,
            'timestamp_taken': None,
            'latitude': None,
            'longitude': None,
            'altitude': None,
            'orientation': None,
            'flash': None,
            'focal_length': None,
            'exposure_time': None,
            'f_number': None,
            'iso': None,
            'all_exif': {}
        }
        
        try:
            # Open image
            with Image.open(image_path) as img:
                # Basic info
                metadata['dimensions'] = f"{img.width}x{img.height}"
                metadata['format'] = img.format
                metadata['mode'] = img.mode
                metadata['file_size'] = Path(image_path).stat().st_size
                
                # Get EXIF data
                exif_data = img._getexif()
                
                if exif_data:
                    # Process standard EXIF tags
                    for tag_id, value in exif_data.items():
                        tag = TAGS.get(tag_id, tag_id)
                        metadata['all_exif'][tag] = str(value)
                        
                        # Extract specific important fields
                        if tag == 'Make':
                            metadata['camera_make'] = value
                        elif tag == 'Model':
                            metadata['camera_model'] = value
                        elif tag == 'Software':
                            metadata['software'] = value
                        elif tag == 'DateTime':
                            metadata['timestamp_taken'] = value
                        elif tag == 'Orientation':
                            metadata['orientation'] = value
                        elif tag == 'Flash':
                            metadata['flash'] = value
                        elif tag == 'FocalLength':
                            metadata['focal_length'] = value
                        elif tag == 'ExposureTime':
                            metadata['exposure_time'] = value
                        elif tag == 'FNumber':
                            metadata['f_number'] = value
                        elif tag == 'ISOSpeedRatings':
                            metadata['iso'] = value
                        elif tag == 'GPSInfo':
                            # Process GPS data
                            gps_info = {}
                            for gps_tag_id in value:
                                gps_tag = GPSTAGS.get(gps_tag_id, gps_tag_id)
                                gps_info[gps_tag] = value[gps_tag_id]
                            
                            # Get decimal coordinates
                            lat, lon = self.get_decimal_coordinates(gps_info)
                            metadata['latitude'] = lat
                            metadata['longitude'] = lon
                            
                            if 'GPSAltitude' in gps_info:
                                metadata['altitude'] = float(gps_info['GPSAltitude'])
                    
                    logger.info(f"Successfully extracted {len(metadata['all_exif'])} EXIF tags")
                else:
                    logger.warning("No EXIF data found in image")
            
            # Save to database
            self.db.save_image_metadata(metadata['filename'], metadata)
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error extracting metadata: {e}")
            return metadata
    
    def extract_from_multiple(self, image_paths):
        """
        Extract metadata from multiple images
        
        Args:
            image_paths: List of image file paths
        
        Returns:
            list: List of metadata dictionaries
        """
        results = []
        for image_path in image_paths:
            result = self.extract_metadata(image_path)
            results.append(result)
        return results
    
    def generate_map_html(self, images_with_gps):
        """
        Generate HTML map with image locations
        
        Args:
            images_with_gps: List of metadata dicts with GPS data
        
        Returns:
            str: HTML content for map
        """
        if not images_with_gps:
            return None
        
        # Simple HTML map template using Leaflet.js
        html = """<!DOCTYPE html>
<html>
<head>
    <title>Image Locations</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        body { margin: 0; padding: 0; }
        #map { height: 100vh; width: 100%; }
    </style>
</head>
<body>
    <div id="map"></div>
    <script>
        var map = L.map('map').setView([0, 0], 2);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        var markers = [];
"""
        
        for img in images_with_gps:
            if img['latitude'] and img['longitude']:
                html += f"""
        L.marker([{img['latitude']}, {img['longitude']}])
            .addTo(map)
            .bindPopup('<b>{img['filename']}</b><br>Lat: {img['latitude']:.6f}<br>Lon: {img['longitude']:.6f}');
        markers.push([{img['latitude']}, {img['longitude']}]);
"""
        
        html += """
        if (markers.length > 0) {
            var group = new L.featureGroup(markers.map(m => L.marker(m)));
            map.fitBounds(group.getBounds().pad(0.1));
        }
    </script>
</body>
</html>
"""
        return html
    
    def get_location_url(self, latitude, longitude):
        """
        Generate Google Maps URL for coordinates
        
        Args:
            latitude: Latitude coordinate
            longitude: Longitude coordinate
        
        Returns:
            str: Google Maps URL
        """
        if latitude and longitude:
            return f"https://www.google.com/maps?q={latitude},{longitude}"
        return None
    
    def has_gps_data(self, metadata):
        """
        Check if metadata contains GPS data
        
        Args:
            metadata: Metadata dictionary
        
        Returns:
            bool: True if GPS data exists
        """
        return metadata.get('latitude') is not None and metadata.get('longitude') is not None

