#!/usr/bin/env python3
"""
IP Address Geolocation Module
Track and analyze IP addresses
"""

import requests
import socket
from typing import Dict, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


class IPGeolocation:
    """IP address intelligence and geolocation"""
    
    def __init__(self):
        # Free IP geolocation APIs
        self.apis = [
            'http://ip-api.com/json/',  # Free, no key required
            'https://ipapi.co/',         # Free tier available
            'https://ipwhois.app/json/', # Free, no key required
        ]
    
    def validate_ip(self, ip: str) -> bool:
        """Validate IP address format"""
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False
    
    def get_ip_info(self, ip_address: str) -> Dict:
        """
        Get comprehensive geolocation information for an IP address
        Uses multiple free APIs for redundancy
        """
        if not self.validate_ip(ip_address):
            return {
                'valid': False,
                'error': 'Invalid IP address format'
            }
        
        result = {
            'ip': ip_address,
            'valid': True,
            'info': {}
        }
        
        try:
            # Try ip-api.com first (most detailed free API)
            response = requests.get(
                f'http://ip-api.com/json/{ip_address}?fields=66846719',
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('status') == 'success':
                    result['info'] = {
                        'country': data.get('country'),
                        'country_code': data.get('countryCode'),
                        'region': data.get('regionName'),
                        'region_code': data.get('region'),
                        'city': data.get('city'),
                        'zip': data.get('zip'),
                        'latitude': data.get('lat'),
                        'longitude': data.get('lon'),
                        'timezone': data.get('timezone'),
                        'isp': data.get('isp'),
                        'organization': data.get('org'),
                        'as': data.get('as'),
                        'reverse_dns': data.get('reverse'),
                        'mobile': data.get('mobile'),
                        'proxy': data.get('proxy'),
                        'hosting': data.get('hosting'),
                    }
                    
                    # Add Google Maps link
                    if result['info']['latitude'] and result['info']['longitude']:
                        lat = result['info']['latitude']
                        lon = result['info']['longitude']
                        result['info']['maps_url'] = f'https://www.google.com/maps?q={lat},{lon}'
                    
                    logger.info(f"IP lookup successful: {ip_address}")
                else:
                    result['error'] = data.get('message', 'Unknown error')
            else:
                result['error'] = f'API request failed: {response.status_code}'
        
        except requests.exceptions.Timeout:
            result['error'] = 'API request timeout'
            logger.error(f"Timeout looking up IP: {ip_address}")
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error getting IP info: {e}")
        
        return result
    
    def get_my_ip(self) -> Optional[str]:
        """Get public IP address of current machine"""
        try:
            response = requests.get('https://api.ipify.org?format=json', timeout=5)
            if response.status_code == 200:
                return response.json().get('ip')
        except Exception as e:
            logger.error(f"Error getting own IP: {e}")
        
        return None
    
    def check_vpn_proxy(self, ip_address: str) -> Dict:
        """Check if IP is VPN/Proxy/Tor"""
        result = {
            'ip': ip_address,
            'is_vpn': False,
            'is_proxy': False,
            'is_tor': False,
            'is_hosting': False,
            'risk_score': 0
        }
        
        try:
            # Using ipwhois.app for VPN/Proxy detection
            response = requests.get(
                f'https://ipwhois.app/json/{ip_address}',
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Check for VPN/Proxy indicators
                if data.get('type') == 'VPN':
                    result['is_vpn'] = True
                    result['risk_score'] += 30
                
                if data.get('type') == 'Proxy':
                    result['is_proxy'] = True
                    result['risk_score'] += 40
                
                if data.get('type') == 'TOR':
                    result['is_tor'] = True
                    result['risk_score'] += 50
                
                if data.get('type') == 'Hosting':
                    result['is_hosting'] = True
                    result['risk_score'] += 20
                
                result['type'] = data.get('type', 'Unknown')
                result['isp'] = data.get('isp', 'Unknown')
                
        except Exception as e:
            logger.error(f"Error checking VPN/Proxy: {e}")
            result['error'] = str(e)
        
        return result
    
    def bulk_ip_lookup(self, ip_list: list) -> list:
        """Lookup multiple IP addresses"""
        results = []
        
        for ip in ip_list:
            ip = ip.strip()
            if self.validate_ip(ip):
                info = self.get_ip_info(ip)
                results.append(info)
            else:
                results.append({
                    'ip': ip,
                    'valid': False,
                    'error': 'Invalid IP format'
                })
        
        return results
    
    def trace_route(self, target: str) -> Dict:
        """Perform traceroute to target (requires system traceroute)"""
        import subprocess
        
        result = {
            'target': target,
            'hops': []
        }
        
        try:
            # Try to run traceroute command
            cmd = ['traceroute', '-m', '15', target]
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            stdout, stderr = process.communicate(timeout=30)
            
            if process.returncode == 0:
                result['output'] = stdout
                result['success'] = True
            else:
                result['error'] = stderr
                result['success'] = False
                
        except subprocess.TimeoutExpired:
            result['error'] = 'Traceroute timeout'
            result['success'] = False
        except FileNotFoundError:
            result['error'] = 'traceroute command not found'
            result['success'] = False
        except Exception as e:
            result['error'] = str(e)
            result['success'] = False
        
        return result
    
    def get_ip_reputation(self, ip_address: str) -> Dict:
        """Check IP reputation for malicious activity"""
        result = {
            'ip': ip_address,
            'reputation': 'unknown',
            'blacklisted': False,
            'checks': {}
        }
        
        # This would integrate with threat intelligence APIs
        # For now, basic implementation
        
        try:
            # Check AbuseIPDB (would need API key for production)
            result['checks']['abuseipdb'] = f'https://www.abuseipdb.com/check/{ip_address}'
            result['checks']['virustotal'] = f'https://www.virustotal.com/gui/ip-address/{ip_address}'
            result['checks']['shodan'] = f'https://www.shodan.io/host/{ip_address}'
            
        except Exception as e:
            logger.error(f"Error checking reputation: {e}")
        
        return result
