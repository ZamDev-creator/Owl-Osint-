"""
Username Hunter Module - Enhanced Version
Search for username across multiple social media platforms with enhanced features:
- Bio extraction and social media account detection
- Latest media download and EXIF extraction (Instagram & TikTok)
- User confirmation before proceeding
- Clear step-by-step process with waiting for completion

Author: Enhanced by AI Assistant
Version: 2.0
"""

import asyncio
import aiohttp
import json
import re
import tempfile
from pathlib import Path
from tqdm import tqdm
from bs4 import BeautifulSoup
from config import REQUEST_TIMEOUT, USER_AGENT, DATA_DIR
from utils.logger import setup_logger
from utils.database import Database
from modules.image_metadata import ImageMetadata

logger = setup_logger(__name__)


class UsernameHunter:
    """Hunt for usernames across multiple platforms with enhanced data extraction"""
    
    def __init__(self):
        """Initialize username hunter with platforms and database"""
        self.platforms = self._load_platforms()
        self.db = Database()
        self.results = []
        self.image_metadata = ImageMetadata()
        
        # Enhanced regex patterns for detecting social media mentions in bio
        self.social_patterns = {
            'instagram': [
                r'@([a-zA-Z0-9._]{1,30})',  # @username
                r'ig[:\s]+([a-zA-Z0-9._]{1,30})',  # ig: username or ig username
                r'instagram[:\s]+([a-zA-Z0-9._]{1,30})',  # instagram: username
                r'instagram\.com/([a-zA-Z0-9._]{1,30})',  # instagram.com/username
                r'insagram[:\s]+([a-zA-Z0-9._]{1,30})',  # typo: insagram
            ],
            'tiktok': [
                r'tiktok[:\s]+@?([a-zA-Z0-9._]{1,24})',  # tiktok: @username
                r'tiktok\.com/@([a-zA-Z0-9._]{1,24})',  # tiktok.com/@username
                r'tt[:\s]+@?([a-zA-Z0-9._]{1,24})',  # tt: @username
                r'tik[:\s]+tok[:\s]+@?([a-zA-Z0-9._]{1,24})',  # tik tok: @username
            ],
            'twitter': [
                r'twitter[:\s]+@?([a-zA-Z0-9_]{1,15})',  # twitter: @username
                r'x\.com/([a-zA-Z0-9_]{1,15})',  # x.com/username
                r'twitter\.com/([a-zA-Z0-9_]{1,15})',  # twitter.com/username
                r'x[:\s]+@?([a-zA-Z0-9_]{1,15})',  # x: @username (platform X)
            ],
            'youtube': [
                r'youtube[:\s]+@?([a-zA-Z0-9_]{1,30})',  # youtube: @username
                r'youtube\.com/@([a-zA-Z0-9_]{1,30})',  # youtube.com/@username
                r'yt[:\s]+@?([a-zA-Z0-9_]{1,30})',  # yt: @username
                r'youtu\.be/([a-zA-Z0-9_]{1,30})',  # youtu.be/username
            ],
            'facebook': [
                r'facebook[:\s]+([a-zA-Z0-9.]{1,50})',  # facebook: username
                r'fb[:\s]+([a-zA-Z0-9.]{1,50})',  # fb: username
                r'facebook\.com/([a-zA-Z0-9.]{1,50})',  # facebook.com/username
            ],
            'telegram': [
                r't\.me/([a-zA-Z0-9_]{5,32})',  # t.me/username
                r'telegram[:\s]+@?([a-zA-Z0-9_]{5,32})',  # telegram: @username
                r'tele[:\s]+@?([a-zA-Z0-9_]{5,32})',  # tele: @username
            ],
            'github': [
                r'github[:\s]+([a-zA-Z0-9-]{1,39})',  # github: username
                r'github\.com/([a-zA-Z0-9-]{1,39})',  # github.com/username
            ],
            'linkedin': [
                r'linkedin[:\s]+([a-zA-Z0-9-]{3,100})',  # linkedin: username
                r'linkedin\.com/in/([a-zA-Z0-9-]{3,100})',  # linkedin.com/in/username
            ],
            'discord': [
                r'discord[:\s]+([a-zA-Z0-9_]{2,32})',  # discord: username
                r'discord\.gg/([a-zA-Z0-9]{1,20})',  # discord.gg/invite
            ],
            'snapchat': [
                r'snapchat[:\s]+([a-zA-Z0-9._-]{3,15})',  # snapchat: username
                r'snap[:\s]+([a-zA-Z0-9._-]{3,15})',  # snap: username
            ],
            'whatsapp': [
                r'wa\.me/([0-9]{10,15})',  # wa.me/phone
                r'whatsapp[:\s]+([0-9]{10,15})',  # whatsapp: phone
            ],
        }
    
    def _load_platforms(self):
        """
        Load platform configurations from JSON file
        
        Returns:
            list: List of platform configurations
        """
        platforms_file = DATA_DIR / "platforms.json"
        try:
            with open(platforms_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading platforms: {e}")
            # Fallback to hardcoded platforms if file not found
            return [
                {"name": "GitHub", "url": "https://github.com/{}"},
                {"name": "Instagram", "url": "https://www.instagram.com/{}"},
                {"name": "Twitter/X", "url": "https://twitter.com/{}"},
                {"name": "Reddit", "url": "https://www.reddit.com/user/{}"},
                {"name": "YouTube", "url": "https://www.youtube.com/@{}"},
                {"name": "TikTok", "url": "https://www.tiktok.com/@{}"},
                {"name": "Facebook", "url": "https://www.facebook.com/{}"},
                {"name": "LinkedIn", "url": "https://www.linkedin.com/in/{}"},
                {"name": "Pinterest", "url": "https://www.pinterest.com/{}"},
                {"name": "Medium", "url": "https://medium.com/@{}"},
            ]
    
    def extract_social_accounts(self, bio_text):
        """
        Extract social media account mentions from bio text with enhanced detection
        
        Args:
            bio_text: Bio/description text to analyze
        
        Returns:
            dict: Dictionary of detected social media accounts by platform
        """
        if not bio_text:
            return {}
        
        detected_accounts = {}
        bio_lower = bio_text.lower()
        
        for platform, patterns in self.social_patterns.items():
            accounts = set()
            for pattern in patterns:
                matches = re.finditer(pattern, bio_lower, re.IGNORECASE)
                for match in matches:
                    username = match.group(1).strip()
                    # Clean username from trailing punctuation
                    username = username.rstrip('.,!?;:)\'"')
                    username = username.lstrip('(\'\"')
                    
                    # Validate username length
                    if username and len(username) >= 2:
                        accounts.add(username)
            
            if accounts:
                detected_accounts[platform] = sorted(list(accounts))
        
        return detected_accounts
    
    async def download_media(self, session, media_url, save_path):
        """
        Download media file from URL
        
        Args:
            session: aiohttp ClientSession
            media_url: URL of media to download
            save_path: Path to save downloaded file
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            async with session.get(media_url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status == 200:
                    content = await response.read()
                    with open(save_path, 'wb') as f:
                        f.write(content)
                    logger.info(f"✓ Media downloaded: {save_path}")
                    return True
                else:
                    logger.warning(f"✗ Failed to download media: HTTP {response.status}")
                    return False
        except Exception as e:
            logger.error(f"✗ Error downloading media: {str(e)[:100]}")
            return False
    
    async def extract_instagram_bio(self, session, username):
        """
        Extract bio and latest post from Instagram profile with enhanced scraping
        
        Args:
            session: aiohttp ClientSession
            username: Instagram username
        
        Returns:
            dict: Bio data and latest post info
        """
        url = f"https://www.instagram.com/{username}/"
        bio_data = {
            'bio': None,
            'full_name': None,
            'followers': None,
            'following': None,
            'posts_count': None,
            'detected_accounts': {},
            'latest_media_url': None,
            'latest_media_type': None,
            'media_exif': None
        }
        
        print(f"\n[Instagram] Mengekstrak data profil untuk @{username}...")
        
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)) as response:
                if response.status == 200:
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Extract from meta tags (fallback method)
                    meta_desc = soup.find('meta', {'property': 'og:description'})
                    if meta_desc:
                        content = meta_desc.get('content', '')
                        bio_data['bio'] = content
                        print(f"  ✓ Bio ditemukan: {content[:80]}...")
                        
                        # Detect social accounts in bio
                        detected = self.extract_social_accounts(content)
                        if detected:
                            bio_data['detected_accounts'] = detected
                            print(f"  ✓ Akun terdeteksi: {detected}")
                    
                    # Try to extract from JSON-LD script (more reliable)
                    scripts = soup.find_all('script', {'type': 'application/ld+json'})
                    for script in scripts:
                        try:
                            data = json.loads(script.string)
                            if 'description' in data:
                                bio_data['bio'] = data['description']
                                bio_data['detected_accounts'] = self.extract_social_accounts(data['description'])
                        except:
                            pass
                    
                    # Extract from shared data JSON (Instagram's main data structure)
                    # Look for window._sharedData pattern
                    for script in soup.find_all('script'):
                        if script.string and 'window._sharedData' in script.string:
                            try:
                                # Extract JSON data
                                json_text = script.string.split('window._sharedData = ')[1].split(';</script>')[0]
                                shared_data = json.loads(json_text)
                                
                                # Navigate to user data
                                entry_data = shared_data.get('entry_data', {})
                                profile_page = entry_data.get('ProfilePage', [{}])[0]
                                graphql = profile_page.get('graphql', {})
                                user = graphql.get('user', {})
                                
                                if user:
                                    bio_data['bio'] = user.get('biography', '')
                                    bio_data['full_name'] = user.get('full_name', '')
                                    bio_data['followers'] = user.get('edge_followed_by', {}).get('count', 0)
                                    bio_data['following'] = user.get('edge_follow', {}).get('count', 0)
                                    bio_data['posts_count'] = user.get('edge_owner_to_timeline_media', {}).get('count', 0)
                                    
                                    if bio_data['bio']:
                                        bio_data['detected_accounts'] = self.extract_social_accounts(bio_data['bio'])
                                        print(f"  ✓ Bio lengkap: {bio_data['bio'][:80]}...")
                                    
                                    # Get latest post
                                    edges = user.get('edge_owner_to_timeline_media', {}).get('edges', [])
                                    if edges:
                                        latest_post = edges[0]['node']
                                        shortcode = latest_post.get('shortcode', '')
                                        bio_data['latest_media_url'] = f"https://www.instagram.com/p/{shortcode}/"
                                        bio_data['latest_media_type'] = 'video' if latest_post.get('is_video') else 'photo'
                                        print(f"  ✓ Post terbaru ditemukan: {bio_data['latest_media_url']}")
                                        print(f"  ✓ Tipe media: {bio_data['latest_media_type']}")
                                        
                                        # Get direct media URL for download
                                        if latest_post.get('is_video'):
                                            media_url = latest_post.get('video_url', '')
                                        else:
                                            media_url = latest_post.get('display_url', '')
                                        
                                        if media_url:
                                            bio_data['direct_media_url'] = media_url
                                
                            except Exception as e:
                                logger.debug(f"Error parsing shared data: {str(e)[:100]}")
                    
                    logger.info(f"✓ Instagram bio extracted for @{username}")
                    return bio_data
                else:
                    print(f"  ✗ Profil tidak ditemukan atau tidak dapat diakses (HTTP {response.status})")
        
        except Exception as e:
            print(f"  ✗ Error: {str(e)[:100]}")
            logger.debug(f"Error extracting Instagram bio for {username}: {str(e)[:100]}")
        
        return bio_data
    
    async def extract_tiktok_bio(self, session, username):
        """
        Extract bio and latest video from TikTok profile with enhanced scraping
        
        Args:
            session: aiohttp ClientSession
            username: TikTok username
        
        Returns:
            dict: Bio data and latest video info
        """
        url = f"https://www.tiktok.com/@{username}"
        bio_data = {
            'bio': None,
            'full_name': None,
            'followers': None,
            'following': None,
            'likes': None,
            'detected_accounts': {},
            'latest_media_url': None,
            'latest_media_type': 'video',
            'media_exif': None
        }
        
        print(f"\n[TikTok] Mengekstrak data profil untuk @{username}...")
        
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)) as response:
                if response.status == 200:
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Extract from meta tags
                    meta_desc = soup.find('meta', {'name': 'description'})
                    if meta_desc:
                        content = meta_desc.get('content', '')
                        bio_data['bio'] = content
                        print(f"  ✓ Bio ditemukan: {content[:80]}...")
                        
                        detected = self.extract_social_accounts(content)
                        if detected:
                            bio_data['detected_accounts'] = detected
                            print(f"  ✓ Akun terdeteksi: {detected}")
                    
                    # Try to extract from script tags
                    scripts = soup.find_all('script', {'id': '__UNIVERSAL_DATA_FOR_REHYDRATION__'})
                    for script in scripts:
                        try:
                            data = json.loads(script.string)
                            # Navigate TikTok's data structure
                            user_detail = data.get('__DEFAULT_SCOPE__', {}).get('webapp.user-detail', {})
                            user_info = user_detail.get('userInfo', {})
                            user = user_info.get('user', {})
                            stats = user_info.get('stats', {})
                            
                            if user:
                                bio_data['bio'] = user.get('signature', '')
                                bio_data['full_name'] = user.get('nickname', '')
                                bio_data['followers'] = stats.get('followerCount', 0)
                                bio_data['following'] = stats.get('followingCount', 0)
                                bio_data['likes'] = stats.get('heartCount', 0)
                                
                                if bio_data['bio']:
                                    bio_data['detected_accounts'] = self.extract_social_accounts(bio_data['bio'])
                                    print(f"  ✓ Bio lengkap: {bio_data['bio'][:80]}...")
                            
                            # Get latest video
                            item_list = user_detail.get('itemList', [])
                            if item_list:
                                latest_video = item_list[0]
                                video_id = latest_video.get('id', '')
                                bio_data['latest_media_url'] = f"https://www.tiktok.com/@{username}/video/{video_id}"
                                print(f"  ✓ Video terbaru ditemukan: {bio_data['latest_media_url']}")
                                
                                # Get video download URL (may need additional processing)
                                video_obj = latest_video.get('video', {})
                                download_url = video_obj.get('downloadAddr', '')
                                if download_url:
                                    bio_data['direct_media_url'] = download_url
                                
                        except Exception as e:
                            logger.debug(f"Error parsing TikTok data: {str(e)[:100]}")
                    
                    logger.info(f"✓ TikTok bio extracted for @{username}")
                    return bio_data
                else:
                    print(f"  ✗ Profil tidak ditemukan atau tidak dapat diakses (HTTP {response.status})")
        
        except Exception as e:
            print(f"  ✗ Error: {str(e)[:100]}")
            logger.debug(f"Error extracting TikTok bio for {username}: {str(e)[:100]}")
        
        return bio_data
    
    async def extract_media_exif(self, media_path):
        """
        Extract EXIF metadata from downloaded media
        
        Args:
            media_path: Path to media file
        
        Returns:
            dict: Extracted EXIF metadata or None
        """
        try:
            print(f"\n[EXIF] Mengekstrak metadata dari media...")
            metadata = self.image_metadata.extract_metadata(media_path)
            
            if metadata:
                print(f"  ✓ Metadata berhasil diekstrak")
                
                # Display important EXIF data
                important_fields = ['camera_make', 'camera_model', 'timestamp_taken', 
                                   'latitude', 'longitude', 'software']
                
                for field in important_fields:
                    value = metadata.get(field)
                    if value:
                        print(f"    • {field}: {value}")
                
                return metadata
            else:
                print(f"  ✗ Tidak ada metadata EXIF ditemukan")
                return None
                
        except Exception as e:
            print(f"  ✗ Error saat ekstraksi EXIF: {str(e)[:100]}")
            logger.error(f"Error extracting EXIF: {str(e)}")
            return None
    
    async def process_platform_media(self, session, platform_name, bio_data, username):
        """
        Process and download media from platform, then extract EXIF
        
        Args:
            session: aiohttp ClientSession
            platform_name: Name of the platform (Instagram/TikTok)
            bio_data: Bio data containing media info
            username: Username being processed
        
        Returns:
            dict: Updated bio_data with EXIF information
        """
        if not bio_data.get('latest_media_url'):
            return bio_data
        
        # Ask for user confirmation
        print(f"\n╔════════════════════════════════════════════════════════════════╗")
        print(f"║ KONFIRMASI DOWNLOAD MEDIA                                      ║")
        print(f"╠════════════════════════════════════════════════════════════════╣")
        print(f"║ Platform  : {platform_name:<50} ║")
        print(f"║ Username  : @{username:<49} ║")
        print(f"║ Media URL : {bio_data['latest_media_url'][:46]:<46} ║")
        print(f"║ Tipe      : {bio_data.get('latest_media_type', 'unknown'):<50} ║")
        print(f"╚════════════════════════════════════════════════════════════════╝")
        
        try:
            # For automated testing, you can set auto_confirm=True
            auto_confirm = False  # Set to True for testing without user input
            
            if not auto_confirm:
                confirm = input("\nDownload media dan ekstrak EXIF? (y/n): ").strip().lower()
            else:
                confirm = 'y'
                print("\nDownload media dan ekstrak EXIF? (y/n): y [auto-confirmed]")
            
            if confirm == 'y':
                print("\n⏳ Memproses download media...")
                
                # Create temp directory for media
                temp_dir = Path(tempfile.gettempdir()) / 'osint_media'
                temp_dir.mkdir(exist_ok=True)
                
                # Determine file extension
                media_type = bio_data.get('latest_media_type', 'photo')
                ext = '.mp4' if media_type == 'video' else '.jpg'
                temp_file = temp_dir / f"{platform_name.lower()}_{username}{ext}"
                
                # Download media
                if bio_data.get('direct_media_url'):
                    success = await self.download_media(session, bio_data['direct_media_url'], temp_file)
                    
                    if success:
                        print(f"✓ Media berhasil didownload: {temp_file}")
                        
                        # Extract EXIF only for images
                        if media_type != 'video':
                            exif_data = await self.extract_media_exif(temp_file)
                            bio_data['media_exif'] = exif_data
                            bio_data['media_file_path'] = str(temp_file)
                        else:
                            print("  ⓘ Video tidak memiliki EXIF metadata (hanya foto)")
                            bio_data['media_file_path'] = str(temp_file)
                    else:
                        print("✗ Gagal mendownload media")
                else:
                    print("✗ URL download langsung tidak tersedia")
                    print("  ⓘ Scraping media Instagram/TikTok memerlukan API atau metode lebih advanced")
            else:
                print("⊗ Download media dibatalkan oleh user")
                
        except Exception as e:
            print(f"✗ Error saat memproses media: {str(e)[:100]}")
            logger.error(f"Error processing media: {str(e)}")
        
        return bio_data
    
    async def check_username(self, session, username, platform):
        """
        Check if username exists on a specific platform
        Enhanced with bio extraction and media EXIF extraction for Instagram and TikTok
        
        Args:
            session: aiohttp ClientSession
            username: Username to check
            platform: Platform configuration dict
        
        Returns:
            dict: Result with platform, found status, URL, bio, and detected accounts
        """
        url = platform['url'].format(username)
        
        try:
            async with session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
                allow_redirects=True
            ) as response:
                # Check if profile exists based on status code
                if response.status == 200:
                    result = {
                        'platform': platform['name'],
                        'found': True,
                        'url': url,
                        'status_code': response.status,
                        'bio': None,
                        'full_name': None,
                        'detected_accounts': {},
                        'latest_media_url': None,
                        'media_exif': None
                    }
                    
                    # Extract additional data for specific platforms
                    if platform['name'] == 'Instagram':
                        print(f"\n{'═'*70}")
                        print(f"🔍 MENGANALISIS PROFIL INSTAGRAM: @{username}")
                        print(f"{'═'*70}")
                        
                        bio_data = await self.extract_instagram_bio(session, username)
                        result.update(bio_data)
                        
                        # Process media if available
                        if bio_data.get('latest_media_url'):
                            result = await self.process_platform_media(
                                session, 'Instagram', result, username
                            )
                    
                    elif platform['name'] == 'TikTok':
                        print(f"\n{'═'*70}")
                        print(f"🔍 MENGANALISIS PROFIL TIKTOK: @{username}")
                        print(f"{'═'*70}")
                        
                        bio_data = await self.extract_tiktok_bio(session, username)
                        result.update(bio_data)
                        
                        # Process media if available
                        if bio_data.get('latest_media_url'):
                            result = await self.process_platform_media(
                                session, 'TikTok', result, username
                            )
                    
                    return result
                else:
                    return {
                        'platform': platform['name'],
                        'found': False,
                        'url': url,
                        'status_code': response.status,
                        'bio': None,
                        'detected_accounts': {}
                    }
        except asyncio.TimeoutError:
            logger.debug(f"Timeout checking {platform['name']}")
            return {
                'platform': platform['name'],
                'found': False,
                'url': url,
                'status_code': 'Timeout',
                'bio': None,
                'detected_accounts': {}
            }
        except Exception as e:
            logger.debug(f"Error checking {platform['name']}: {str(e)[:50]}")
            return {
                'platform': platform['name'],
                'found': False,
                'url': url,
                'status_code': 'Error',
                'bio': None,
                'detected_accounts': {}
            }
    
    async def hunt(self, username):
        """
        Hunt for username across all platforms with enhanced data extraction
        Shows clear step-by-step progress and waits for completion
        
        Args:
            username: Username to search for
        
        Returns:
            list: List of results for each platform
        """
        print(f"\n{'#'*70}")
        print(f"# MEMULAI PENCARIAN USERNAME: {username}")
        print(f"{'#'*70}\n")
        
        logger.info(f"Starting enhanced username hunt for: {username}")
        
        # Initial confirmation
        print(f"Target   : {username}")
        print(f"Platform : {len(self.platforms)} platform akan dicek")
        print(f"\n⚠️  Proses ini akan:")
        print(f"   • Mencari profil di {len(self.platforms)} platform")
        print(f"   • Mengekstrak bio dan mencari mention akun lain")
        print(f"   • Download media terbaru dari Instagram & TikTok (jika ditemukan)")
        print(f"   • Ekstrak EXIF metadata dari media")
        
        confirm = input(f"\nLanjutkan? (y/n): ").strip().lower()
        if confirm != 'y':
            print("\n⊗ Pencarian dibatalkan oleh user")
            return []
        
        print(f"\n{'─'*70}")
        print(f"TAHAP 1: PENCARIAN PROFIL DI SEMUA PLATFORM")
        print(f"{'─'*70}")
        
        headers = {'User-Agent': USER_AGENT}
        # WARNING: SSL verification is disabled. Enable for production use.
        connector = aiohttp.TCPConnector(limit=10, ssl=False)
        
        async with aiohttp.ClientSession(headers=headers, connector=connector) as session:
            tasks = [
                self.check_username(session, username, platform)
                for platform in self.platforms
            ]
            
            # Use tqdm for progress bar
            with tqdm(
                total=len(tasks), 
                desc="⏳ Checking platforms", 
                ncols=100, 
                bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
            ) as pbar:
                for coro in asyncio.as_completed(tasks):
                    result = await coro
                    self.results.append(result)
                    
                    # Save to database
                    self.db.save_username_result(
                        username,
                        result['platform'],
                        result['found'],
                        result['url']
                    )
                    
                    # Log bio data if available
                    if result.get('bio'):
                        logger.info(f"Bio found on {result['platform']}: {result['bio'][:100]}...")
                    
                    # Log detected accounts
                    if result.get('detected_accounts'):
                        logger.info(f"Detected accounts on {result['platform']}: {result['detected_accounts']}")
                    
                    pbar.update(1)
        
        # Wait for all tasks to complete
        print(f"\n✓ Semua platform selesai dicek!")
        
        # Sort results: found first
        self.results.sort(key=lambda x: (not x['found'], x['platform']))
        
        found_count = sum(1 for r in self.results if r['found'])
        
        print(f"\n{'─'*70}")
        print(f"TAHAP 2: RINGKASAN HASIL")
        print(f"{'─'*70}")
        print(f"\n✓ Profil ditemukan: {found_count}/{len(self.results)} platform")
        
        # Display found platforms
        if found_count > 0:
            print(f"\nPlatform yang ditemukan:")
            for result in self.results:
                if result['found']:
                    print(f"  ✓ {result['platform']:<15} → {result['url']}")
        
        # Compile all detected accounts across platforms
        all_detected_accounts = self.compile_detected_accounts()
        
        if all_detected_accounts:
            print(f"\n{'─'*70}")
            print(f"TAHAP 3: AKUN TERDETEKSI DI BIO")
            print(f"{'─'*70}\n")
            
            for platform, accounts in all_detected_accounts.items():
                print(f"{platform.capitalize():<12}: {', '.join(accounts)}")
            
            logger.info(f"Total detected accounts across all platforms: {all_detected_accounts}")
        
        # Display platforms with bio
        platforms_with_bio = self.get_platforms_with_bio()
        if platforms_with_bio:
            print(f"\n{'─'*70}")
            print(f"TAHAP 4: BIO & DESKRIPSI PROFIL")
            print(f"{'─'*70}\n")
            
            for result in platforms_with_bio:
                print(f"Platform: {result['platform']}")
                print(f"Bio: {result['bio'][:200]}...")
                if result.get('detected_accounts'):
                    print(f"Akun terdeteksi: {result['detected_accounts']}")
                print()
        
        # Display media extraction results
        media_results = [r for r in self.results if r.get('media_exif')]
        if media_results:
            print(f"\n{'─'*70}")
            print(f"TAHAP 5: HASIL EKSTRAKSI MEDIA & EXIF")
            print(f"{'─'*70}\n")
            
            for result in media_results:
                print(f"Platform: {result['platform']}")
                print(f"Media URL: {result.get('latest_media_url', 'N/A')}")
                
                exif = result.get('media_exif', {})
                if exif:
                    print(f"\nEXIF Data:")
                    if exif.get('camera_make'):
                        print(f"  • Camera: {exif['camera_make']} {exif.get('camera_model', '')}")
                    if exif.get('timestamp_taken'):
                        print(f"  • Date Taken: {exif['timestamp_taken']}")
                    if exif.get('latitude') and exif.get('longitude'):
                        print(f"  • GPS: {exif['latitude']:.6f}, {exif['longitude']:.6f}")
                        print(f"  • Maps: {self.image_metadata.get_location_url(exif['latitude'], exif['longitude'])}")
                    if exif.get('software'):
                        print(f"  • Software: {exif['software']}")
                print()
        
        print(f"\n{'#'*70}")
        print(f"# PENCARIAN SELESAI!")
        print(f"{'#'*70}\n")
        
        logger.info(f"Hunt complete: {found_count}/{len(self.results)} profiles found")
        
        return self.results
    
    def compile_detected_accounts(self):
        """
        Compile all detected social media accounts from all found profiles
        
        Returns:
            dict: Dictionary of all detected accounts grouped by platform
        """
        compiled = {}
        
        for result in self.results:
            if result.get('detected_accounts'):
                for platform, accounts in result['detected_accounts'].items():
                    if platform not in compiled:
                        compiled[platform] = set()
                    compiled[platform].update(accounts)
        
        # Convert sets back to lists
        return {platform: sorted(list(accounts)) for platform, accounts in compiled.items()}
    
    def get_results(self):
        """
        Get search results
        
        Returns:
            list: List of search results
        """
        return self.results
    
    def get_found_platforms(self):
        """
        Get only platforms where username was found
        
        Returns:
            list: List of found platforms
        """
        return [r for r in self.results if r['found']]
    
    def get_not_found_platforms(self):
        """
        Get platforms where username was not found
        
        Returns:
            list: List of not found platforms
        """
        return [r for r in self.results if not r['found']]
    
    def get_platforms_with_bio(self):
        """
        Get platforms where bio/description was found
        
        Returns:
            list: List of platforms with bio data
        """
        return [r for r in self.results if r.get('bio')]
    
    def get_all_detected_accounts(self):
        """
        Get all detected social media accounts
        
        Returns:
            dict: Compiled dictionary of all detected accounts
        """
        return self.compile_detected_accounts()
    
    def get_media_extraction_results(self):
        """
        Get platforms where media was successfully extracted
        
        Returns:
            list: List of platforms with media EXIF data
        """
        return [r for r in self.results if r.get('media_exif')]
