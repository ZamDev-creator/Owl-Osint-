#!/usr/bin/env python3
"""
Blockchain Address Tracking Module
Track cryptocurrency addresses and transactions
"""

import requests
from typing import Dict, List, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


class BlockchainTracker:
    """Cryptocurrency address tracking and analysis"""
    
    def __init__(self):
        self.bitcoin_api = 'https://blockchain.info/rawaddr/'
        self.ethereum_api = 'https://api.etherscan.io/api'
        self.blockchair_api = 'https://api.blockchair.com'
    
    def detect_address_type(self, address: str) -> str:
        """Detect cryptocurrency type from address format"""
        address = address.strip()
        
        # Bitcoin
        if address.startswith('1') or address.startswith('3') or address.startswith('bc1'):
            if len(address) >= 26 and len(address) <= 35:
                return 'bitcoin'
        
        # Ethereum
        if address.startswith('0x') and len(address) == 42:
            return 'ethereum'
        
        # Litecoin
        if (address.startswith('L') or address.startswith('M')) and len(address) == 34:
            return 'litecoin'
        
        # Dogecoin
        if address.startswith('D') and len(address) == 34:
            return 'dogecoin'
        
        # Bitcoin Cash
        if address.startswith('q') or address.startswith('p'):
            return 'bitcoin_cash'
        
        # Ripple (XRP)
        if address.startswith('r') and len(address) >= 25 and len(address) <= 35:
            return 'ripple'
        
        # Monero
        if address.startswith('4') and len(address) == 95:
            return 'monero'
        
        return 'unknown'
    
    def track_bitcoin_address(self, address: str) -> Dict:
        """Track Bitcoin address using Blockchain.info API"""
        result = {
            'address': address,
            'type': 'bitcoin',
            'success': False
        }
        
        try:
            response = requests.get(
                f'https://blockchain.info/rawaddr/{address}?limit=50',
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                
                result['success'] = True
                result['info'] = {
                    'total_received': data.get('total_received', 0) / 100000000,  # Convert to BTC
                    'total_sent': data.get('total_sent', 0) / 100000000,
                    'final_balance': data.get('final_balance', 0) / 100000000,
                    'n_tx': data.get('n_tx', 0),
                    'total_transactions': data.get('n_tx', 0),
                }
                
                # Get recent transactions
                transactions = data.get('txs', [])[:10]
                result['recent_transactions'] = []
                
                for tx in transactions:
                    result['recent_transactions'].append({
                        'hash': tx.get('hash'),
                        'time': tx.get('time'),
                        'size': tx.get('size'),
                        'block_height': tx.get('block_height'),
                    })
                
                # Explorer links
                result['explorer_links'] = {
                    'blockchain_info': f'https://www.blockchain.com/btc/address/{address}',
                    'blockchair': f'https://blockchair.com/bitcoin/address/{address}',
                    'blockcypher': f'https://live.blockcypher.com/btc/address/{address}/',
                }
                
                logger.info(f"Bitcoin address tracked: {address}")
            else:
                result['error'] = f'API error: {response.status_code}'
        
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error tracking Bitcoin address: {e}")
        
        return result
    
    def track_ethereum_address(self, address: str) -> Dict:
        """Track Ethereum address using Etherscan API"""
        result = {
            'address': address,
            'type': 'ethereum',
            'success': False
        }
        
        try:
            # Get balance using Etherscan API (no key needed for balance)
            params = {
                'module': 'account',
                'action': 'balance',
                'address': address,
                'tag': 'latest',
            }
            
            response = requests.get(
                'https://api.etherscan.io/api',
                params=params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('status') == '1':
                    balance_wei = int(data.get('result', '0'))
                    balance_eth = balance_wei / 1000000000000000000  # Convert Wei to ETH
                    
                    result['success'] = True
                    result['info'] = {
                        'balance': balance_eth,
                        'balance_wei': balance_wei,
                    }
                    
                    # Get transaction count
                    params['action'] = 'txlist'
                    params['page'] = 1
                    params['offset'] = 10
                    params['sort'] = 'desc'
                    
                    tx_response = requests.get(
                        'https://api.etherscan.io/api',
                        params=params,
                        timeout=15
                    )
                    
                    if tx_response.status_code == 200:
                        tx_data = tx_response.json()
                        if tx_data.get('status') == '1':
                            result['info']['total_transactions'] = len(tx_data.get('result', []))
                            result['recent_transactions'] = tx_data.get('result', [])[:5]
                    
                    # Explorer links
                    result['explorer_links'] = {
                        'etherscan': f'https://etherscan.io/address/{address}',
                        'blockchair': f'https://blockchair.com/ethereum/address/{address}',
                        'ethplorer': f'https://ethplorer.io/address/{address}',
                    }
                    
                    logger.info(f"Ethereum address tracked: {address}")
                else:
                    result['error'] = data.get('message', 'Unknown error')
            else:
                result['error'] = f'API error: {response.status_code}'
        
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error tracking Ethereum address: {e}")
        
        return result
    
    def track_address(self, address: str) -> Dict:
        """Auto-detect and track any cryptocurrency address"""
        crypto_type = self.detect_address_type(address)
        
        result = {
            'address': address,
            'detected_type': crypto_type,
        }
        
        if crypto_type == 'bitcoin':
            return self.track_bitcoin_address(address)
        elif crypto_type == 'ethereum':
            return self.track_ethereum_address(address)
        elif crypto_type == 'unknown':
            result['error'] = 'Unable to detect cryptocurrency type'
            result['success'] = False
        else:
            # For other types, provide explorer links
            result['info'] = {
                'message': f'Direct tracking not implemented for {crypto_type}'
            }
            result['explorer_links'] = self._get_explorer_links(address, crypto_type)
            result['success'] = True
        
        return result
    
    def _get_explorer_links(self, address: str, crypto_type: str) -> Dict:
        """Get blockchain explorer links for various cryptocurrencies"""
        links = {}
        
        if crypto_type == 'bitcoin':
            links = {
                'blockchain_info': f'https://www.blockchain.com/btc/address/{address}',
                'blockchair': f'https://blockchair.com/bitcoin/address/{address}',
                'blockcypher': f'https://live.blockcypher.com/btc/address/{address}/',
            }
        elif crypto_type == 'ethereum':
            links = {
                'etherscan': f'https://etherscan.io/address/{address}',
                'blockchair': f'https://blockchair.com/ethereum/address/{address}',
            }
        elif crypto_type == 'litecoin':
            links = {
                'blockchair': f'https://blockchair.com/litecoin/address/{address}',
                'blockcypher': f'https://live.blockcypher.com/ltc/address/{address}/',
            }
        elif crypto_type == 'dogecoin':
            links = {
                'blockchair': f'https://blockchair.com/dogecoin/address/{address}',
                'dogechain': f'https://dogechain.info/address/{address}',
            }
        elif crypto_type == 'bitcoin_cash':
            links = {
                'blockchair': f'https://blockchair.com/bitcoin-cash/address/{address}',
            }
        elif crypto_type == 'ripple':
            links = {
                'xrpscan': f'https://xrpscan.com/account/{address}',
                'blockchair': f'https://blockchair.com/ripple/account/{address}',
            }
        
        return links
    
    def analyze_transaction(self, tx_hash: str, crypto_type: str = 'bitcoin') -> Dict:
        """Analyze a specific transaction"""
        result = {
            'tx_hash': tx_hash,
            'crypto_type': crypto_type,
            'success': False
        }
        
        try:
            if crypto_type == 'bitcoin':
                response = requests.get(
                    f'https://blockchain.info/rawtx/{tx_hash}',
                    timeout=15
                )
                
                if response.status_code == 200:
                    data = response.json()
                    result['success'] = True
                    result['info'] = {
                        'hash': data.get('hash'),
                        'size': data.get('size'),
                        'block_height': data.get('block_height'),
                        'time': data.get('time'),
                        'inputs': len(data.get('inputs', [])),
                        'outputs': len(data.get('out', [])),
                    }
                    
                    result['explorer_link'] = f'https://www.blockchain.com/btc/tx/{tx_hash}'
            
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error analyzing transaction: {e}")
        
        return result
    
    def get_address_labels(self, address: str, crypto_type: str = 'bitcoin') -> Dict:
        """Check if address has known labels (exchanges, etc.)"""
        # This would integrate with label databases
        result = {
            'address': address,
            'labels': [],
            'known_entity': False
        }
        
        # Common known addresses (example)
        known_addresses = {
            'bitcoin': {
                '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa': 'Satoshi Nakamoto (Genesis)',
            },
            'ethereum': {
                '0x00000000219ab540356cbb839cbe05303d7705fa': 'Ethereum 2.0 Deposit Contract',
            }
        }
        
        if crypto_type in known_addresses:
            if address in known_addresses[crypto_type]:
                result['labels'].append(known_addresses[crypto_type][address])
                result['known_entity'] = True
        
        return result
