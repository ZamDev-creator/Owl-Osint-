"""
Email OSINT Module
Analyze email addresses for validation, breaches, and disposable domains
"""

import re
import requests
from config import EMAIL_REGEX, USER_AGENT, HIBP_API_KEY
from utils.logger import setup_logger
from utils.database import Database

logger = setup_logger(__name__)


class EmailOSINT:
    """Perform OSINT analysis on email addresses"""
    
    def __init__(self):
        """Initialize email OSINT with database and disposable domains list"""
        self.db = Database()
        
        # List of known disposable email domains
        self.disposable_domains = [
            'tempmail.com', 'guerrillamail.com', '10minutemail.com',
            'mailinator.com', 'throwaway.email', 'temp-mail.org',
            'fakeinbox.com', 'maildrop.cc', 'trashmail.com',
            'getnada.com', 'temp-mail.io', 'mohmal.com',
            'yopmail.com', 'sharklasers.com', 'guerrillamail.info',
            'grr.la', 'guerrillamail.biz', 'guerrillamail.de',
            'spam4.me', 'tmpeml.info', 'emailondeck.com'
        ]
    
    def validate_format(self, email):
        """
        Validate email format using regex
        
        Args:
            email: Email address to validate
        
        Returns:
            bool: True if format is valid
        """
        return re.match(EMAIL_REGEX, email) is not None
    
    def check_disposable(self, email):
        """
        Check if email is from a disposable domain
        
        Args:
            email: Email address to check
        
        Returns:
            bool: True if disposable domain
        """
        try:
            domain = email.split('@')[1].lower()
            return domain in self.disposable_domains
        except Exception as e:
            logger.error(f"Error: {e}")
            return False
    
    def check_breach(self, email):
        """
        Check if email is in known data breaches using HaveIBeenPwned
        
        Args:
            email: Email address to check
        
        Returns:
            tuple: (breached, breach_count)
        """
        # Note: HIBP API requires API key for automated checking
        
        if not HIBP_API_KEY:
            logger.warning("HIBP API key not set. Using simulated breach check for demo.")
            # Simulate breach check for demo purposes
            import random
            breached = random.choice([True, False])
            breach_count = random.randint(1, 5) if breached else 0
            return breached, breach_count
        
        try:
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
            headers = {
                'User-Agent': USER_AGENT,
                'hibp-api-key': HIBP_API_KEY
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                breaches = response.json()
                return True, len(breaches)
            elif response.status_code == 404:
                return False, 0
            else:
                logger.warning(f"HIBP API returned status {response.status_code}")
                return None, 0
        except Exception as e:
            logger.error(f"Error checking breaches: {e}")
            return None, 0
    
    def extract_username_domain(self, email):
        """
        Extract username and domain from email
        
        Args:
            email: Email address
        
        Returns:
            tuple: (username, domain)
        """
        try:
            username, domain = email.split('@')
            return username, domain
        except Exception as e:
            logger.error(f"Error: {e}")
            return None, None
    
    def analyze(self, email):
        """
        Perform complete OSINT analysis on email
        
        Args:
            email: Email address to analyze
        
        Returns:
            dict: Analysis results
        """
        logger.info(f"Starting email analysis for: {email}")
        
        results = {
            'email': email,
            'valid': False,
            'disposable': False,
            'breached': False,
            'breach_count': 0,
            'domain': None,
            'username': None
        }
        
        # Validate format
        results['valid'] = self.validate_format(email)
        if not results['valid']:
            logger.warning(f"Invalid email format: {email}")
            return results
        
        # Extract parts
        username, domain = self.extract_username_domain(email)
        results['username'] = username
        results['domain'] = domain
        
        # Check if disposable
        results['disposable'] = self.check_disposable(email)
        if results['disposable']:
            logger.info(f"Email is from a disposable domain: {domain}")
        
        # Check breaches
        breached, breach_count = self.check_breach(email)
        results['breached'] = breached if breached is not None else False
        results['breach_count'] = breach_count
        
        if results['breached']:
            logger.warning(f"⚠️ Email found in {breach_count} breach(es)!")
        else:
            logger.info("✓ Email not found in known breaches")
        
        # Save to database
        self.db.save_email_result(
            email,
            results['breached'],
            results['breach_count'],
            results['disposable'],
            results['valid']
        )
        
        return results
    
    def bulk_analyze(self, emails):
        """
        Analyze multiple emails
        
        Args:
            emails: List of email addresses
        
        Returns:
            list: List of analysis results
        """
        results = []
        for email in emails:
            result = self.analyze(email)
            results.append(result)
        return results
    
    def get_domain_info(self, domain):
        """
        Get basic information about email domain
        
        Args:
            domain: Domain name
        
        Returns:
            dict: Domain information
        """
        info = {
            'domain': domain,
            'is_disposable': domain.lower() in self.disposable_domains,
            'common_provider': self._is_common_provider(domain)
        }
        return info
    
    def _is_common_provider(self, domain):
        """
        Check if domain is a common email provider
        
        Args:
            domain: Domain name
        
        Returns:
            str: Provider name or None
        """
        common_providers = {
            'gmail.com': 'Google Gmail',
            'yahoo.com': 'Yahoo Mail',
            'outlook.com': 'Microsoft Outlook',
            'hotmail.com': 'Microsoft Hotmail',
            'icloud.com': 'Apple iCloud',
            'protonmail.com': 'ProtonMail',
            'aol.com': 'AOL Mail'
        }
        return common_providers.get(domain.lower())

