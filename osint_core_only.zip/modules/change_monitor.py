"""
Change Monitor Module
Monitor websites for content changes using hash-based detection
"""

import hashlib
import requests
import time
from datetime import datetime
from bs4 import BeautifulSoup
from config import USER_AGENT, REQUEST_TIMEOUT, MONITOR_INTERVAL, MAX_CONTENT_SIZE
from utils.logger import setup_logger
from utils.database import Database

logger = setup_logger(__name__)


class ChangeMonitor:
    """Monitor websites for content changes"""
    
    def __init__(self):
        """Initialize change monitor with database"""
        self.db = Database()
        self.monitored_urls = {}
    
    def get_content_hash(self, content):
        """
        Generate SHA-256 hash of content for comparison
        
        Args:
            content: Content string to hash
        
        Returns:
            str: SHA-256 hash hexdigest
        """
        return hashlib.sha256(content.encode('utf-8')).hexdigest()
    
    def fetch_url_content(self, url):
        """
        Fetch content from URL
        
        Args:
            url: URL to fetch
        
        Returns:
            tuple: (content, status_code)
        """
        try:
            headers = {'User-Agent': USER_AGENT}
            response = requests.get(
                url,
                headers=headers,
                timeout=REQUEST_TIMEOUT,
                allow_redirects=True
            )
            
            if response.status_code == 200:
                # Limit content size to prevent memory issues
                content = response.text[:MAX_CONTENT_SIZE]
                return content, response.status_code
            else:
                logger.warning(f"HTTP {response.status_code} for {url}")
                return None, response.status_code
        except requests.exceptions.Timeout:
            logger.error(f"Timeout fetching {url}")
            return None, 'Timeout'
        except Exception as e:
            logger.error(f"Error fetching {url}: {e}")
            return None, 'Error'
    
    def extract_text_content(self, html_content):
        """
        Extract text content from HTML for better comparison
        Removes scripts, styles, and normalizes whitespace
        
        Args:
            html_content: HTML content string
        
        Returns:
            str: Cleaned text content
        """
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Get text
            text = soup.get_text()
            
            # Clean up whitespace
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            return text
        except Exception as e:
            logger.error(f"Error parsing HTML: {e}")
            return html_content
    
    def add_url(self, url):
        """
        Add URL to monitoring list
        
        Args:
            url: URL to monitor
        
        Returns:
            bool: Success status
        """
        logger.info(f"Adding URL to monitor: {url}")
        
        # Fetch initial content
        content, status = self.fetch_url_content(url)
        
        if content:
            # Extract text for better comparison
            text_content = self.extract_text_content(content)
            content_hash = self.get_content_hash(text_content)
            
            # Save to database
            success = self.db.add_monitored_url(url, content_hash)
            
            if success:
                self.monitored_urls[url] = {
                    'hash': content_hash,
                    'last_check': datetime.now(),
                    'status': status
                }
                logger.info(f"✓ Successfully added {url} to monitoring")
                return True
            else:
                logger.error(f"Failed to add {url} to database")
                return False
        else:
            logger.error(f"Could not fetch initial content from {url}")
            return False
    
    def check_url(self, url, old_hash):
        """
        Check if URL content has changed
        
        Args:
            url: URL to check
            old_hash: Previous content hash
        
        Returns:
            tuple: (changed, new_hash, status)
        """
        content, status = self.fetch_url_content(url)
        
        if not content:
            return False, old_hash, "Failed to fetch"
        
        text_content = self.extract_text_content(content)
        new_hash = self.get_content_hash(text_content)
        
        changed = (new_hash != old_hash)
        
        return changed, new_hash, status
    
    def check_all(self):
        """
        Check all monitored URLs for changes
        
        Returns:
            list: List of detected changes
        """
        logger.info("Starting change detection check...")
        
        # Load monitored URLs from database
        db_urls = self.db.get_monitored_urls()
        
        changes_detected = []
        
        for row in db_urls:
            url_id, url, last_hash, last_check, change_detected, created_at = row
            
            logger.info(f"Checking: {url}")
            
            changed, new_hash, status = self.check_url(url, last_hash)
            
            if changed:
                logger.warning(f"⚠️ CHANGE DETECTED: {url}")
                changes_detected.append({
                    'url': url,
                    'old_hash': last_hash,
                    'new_hash': new_hash,
                    'detected_at': datetime.now()
                })
            else:
                logger.info(f"✓ No changes: {url}")
            
            # Update database
            self.db.update_monitored_url(url, new_hash, changed)
            
            # Small delay between checks to be polite
            time.sleep(1)
        
        if changes_detected:
            logger.warning(f"Total changes detected: {len(changes_detected)}")
        else:
            logger.info("No changes detected in any monitored URLs")
        
        return changes_detected
    
    def monitor_continuously(self, interval=MONITOR_INTERVAL):
        """
        Continuously monitor URLs at specified interval
        
        Args:
            interval: Check interval in seconds (default from config)
        """
        logger.info(f"Starting continuous monitoring (interval: {interval}s)")
        logger.info("Press Ctrl+C to stop monitoring")
        
        try:
            while True:
                changes = self.check_all()
                
                if changes:
                    for change in changes:
                        logger.warning(f"🔔 ALERT: {change['url']} has changed!")
                
                logger.info(f"Waiting {interval} seconds until next check...")
                time.sleep(interval)
        except KeyboardInterrupt:
            logger.info("\n⏹️ Monitoring stopped by user")
    
    def list_monitored_urls(self):
        """
        List all monitored URLs
        
        Returns:
            list: List of monitored URL records
        """
        return self.db.get_monitored_urls()
    
    def remove_url(self, url):
        """
        Remove URL from monitoring
        
        Args:
            url: URL to remove
        
        Returns:
            bool: Success status
        """
        success = self.db.remove_monitored_url(url)
        if success:
            logger.info(f"✓ Removed {url} from monitoring")
            if url in self.monitored_urls:
                del self.monitored_urls[url]
        else:
            logger.error(f"Failed to remove {url}")
        return success
    
    def get_url_status(self, url):
        """
        Get current status of monitored URL
        
        Args:
            url: URL to check status
        
        Returns:
            dict: Status information or None
        """
        urls = self.db.get_monitored_urls()
        for row in urls:
            if row[1] == url:  # row[1] is the URL
                return {
                    'id': row[0],
                    'url': row[1],
                    'last_hash': row[2],
                    'last_check': row[3],
                    'change_detected': row[4],
                    'created_at': row[5]
                }
        return None

