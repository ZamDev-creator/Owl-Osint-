"""
Report Generator for OSINT Suite
Generates professional HTML reports for various modules
"""

from datetime import datetime
from pathlib import Path
from config import REPORTS_DIR
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ReportGenerator:
    """Generate HTML reports for OSINT results"""
    
    def __init__(self):
        """Initialize report generator with timestamp"""
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    def generate_username_report(self, username, results):
        """
        Generate HTML report for username search
        
        Args:
            username: Username that was searched
            results: List of search results
        
        Returns:
            Path: Path to generated report
        """
        
        found_platforms = [r for r in results if r['found']]
        not_found_platforms = [r for r in results if not r['found']]
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Username Search Report - {username}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .stat-number {{
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
        }}
        .stat-label {{
            color: #666;
            margin-top: 5px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
        .platform-list {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        .platform-item {{
            padding: 15px;
            border-radius: 5px;
            background: #f8f9fa;
            border-left: 4px solid #28a745;
        }}
        .platform-item.not-found {{
            border-left-color: #dc3545;
            opacity: 0.6;
        }}
        .platform-name {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .platform-url {{
            font-size: 14px;
            color: #666;
            word-break: break-all;
        }}
        .platform-url a {{
            color: #667eea;
            text-decoration: none;
        }}
        .platform-url a:hover {{
            text-decoration: underline;
        }}
        .footer {{
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 Username Search Report</h1>
        <p>Target Username: <strong>{username}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-number">{len(results)}</div>
            <div class="stat-label">Platforms Checked</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len(found_platforms)}</div>
            <div class="stat-label">Profiles Found</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len(not_found_platforms)}</div>
            <div class="stat-label">Not Found</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{round(len(found_platforms)/len(results)*100) if results else 0}%</div>
            <div class="stat-label">Success Rate</div>
        </div>
    </div>
    
    <div class="section">
        <h2>✅ Found Profiles ({len(found_platforms)})</h2>
        <div class="platform-list">
"""
        
        for result in found_platforms:
            html_content += f"""
            <div class="platform-item">
                <div class="platform-name">{result['platform']}</div>
                <div class="platform-url"><a href="{result['url']}" target="_blank">{result['url']}</a></div>
            </div>
"""
        
        html_content += f"""
        </div>
    </div>
    
    <div class="section">
        <h2>❌ Not Found ({len(not_found_platforms)})</h2>
        <div class="platform-list">
"""
        
        for result in not_found_platforms:
            html_content += f"""
            <div class="platform-item not-found">
                <div class="platform-name">{result['platform']}</div>
                <div class="platform-url">{result['url']}</div>
            </div>
"""
        
        html_content += """
        </div>
    </div>
    
    <div class="footer">
        <p>Generated by OSINT Suite | All data collected from publicly available sources</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"username_{username}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {report_path}")
        return report_path
    
    def generate_email_report(self, email, data):
        """
        Generate HTML report for email OSINT
        
        Args:
            email: Email address analyzed
            data: Analysis results
        
        Returns:
            Path: Path to generated report
        """
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email OSINT Report - {email}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #f5576c;
            padding-bottom: 10px;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .info-item {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #f5576c;
        }}
        .info-label {{
            font-weight: bold;
            color: #666;
            margin-bottom: 5px;
        }}
        .info-value {{
            font-size: 18px;
            color: #333;
        }}
        .alert {{
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
        }}
        .alert-danger {{
            background-color: #f8d7da;
            border-left: 4px solid #dc3545;
            color: #721c24;
        }}
        .alert-success {{
            background-color: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }}
        .alert-warning {{
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            color: #856404;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📧 Email OSINT Report</h1>
        <p>Target Email: <strong>{email}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>Email Validation</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Format Valid</div>
                <div class="info-value">{'✅ Yes' if data.get('valid') else '❌ No'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Disposable Email</div>
                <div class="info-value">{'⚠️ Yes' if data.get('disposable') else '✅ No'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Domain</div>
                <div class="info-value">{email.split('@')[1] if '@' in email else 'N/A'}</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2>Breach Status</h2>
"""
        
        if data.get('breached'):
            html_content += f"""
        <div class="alert alert-danger">
            <strong>⚠️ WARNING:</strong> This email has been found in {data.get('breach_count', 0)} data breach(es)!
        </div>
        <p>This email address has appeared in known data breaches. The account holder should:</p>
        <ul>
            <li>Change passwords immediately</li>
            <li>Enable two-factor authentication</li>
            <li>Monitor for suspicious activity</li>
        </ul>
"""
        else:
            html_content += """
        <div class="alert alert-success">
            <strong>✅ GOOD NEWS:</strong> This email has not been found in any known data breaches.
        </div>
"""
        
        html_content += """
    </div>
    
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | Data from publicly available breach databases</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"email_{email.replace('@', '_at_')}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {report_path}")
        return report_path

