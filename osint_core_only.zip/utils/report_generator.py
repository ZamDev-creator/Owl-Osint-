"""
Report Generator for OSINT Suite
Generates professional HTML and PDF reports for various modules
"""

from datetime import datetime
from pathlib import Path
from config import REPORTS_DIR
from utils.logger import setup_logger

logger = setup_logger(__name__)

# PDF generation support
try:
    from weasyprint import HTML
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False
    logger.warning("WeasyPrint not installed - PDF generation disabled")


class ReportGenerator:
    """Generate HTML reports for OSINT results"""
    
    def __init__(self):
        """Initialize report generator with timestamp"""
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    def generate_username_report(self, username, results):
        """
        Generate HTML report for username search
        
        Args:
            username: Username that was searched
            results: List of search results
        
        Returns:
            Path: Path to generated report
        """
        
        found_platforms = [r for r in results if r['found']]
        not_found_platforms = [r for r in results if not r['found']]
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Username Search Report - {username}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .stat-number {{
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
        }}
        .stat-label {{
            color: #666;
            margin-top: 5px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
        .platform-list {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        .platform-item {{
            padding: 15px;
            border-radius: 5px;
            background: #f8f9fa;
            border-left: 4px solid #28a745;
        }}
        .platform-item.not-found {{
            border-left-color: #dc3545;
            opacity: 0.6;
        }}
        .platform-name {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .platform-url {{
            font-size: 14px;
            color: #666;
            word-break: break-all;
        }}
        .platform-url a {{
            color: #667eea;
            text-decoration: none;
        }}
        .platform-url a:hover {{
            text-decoration: underline;
        }}
        .footer {{
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 Username Search Report</h1>
        <p>Target Username: <strong>{username}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-number">{len(results)}</div>
            <div class="stat-label">Platforms Checked</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len(found_platforms)}</div>
            <div class="stat-label">Profiles Found</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len(not_found_platforms)}</div>
            <div class="stat-label">Not Found</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{round(len(found_platforms)/len(results)*100) if results else 0}%</div>
            <div class="stat-label">Success Rate</div>
        </div>
    </div>
    
    <div class="section">
        <h2>✅ Found Profiles ({len(found_platforms)})</h2>
        <div class="platform-list">
"""
        
        for result in found_platforms:
            html_content += f"""
            <div class="platform-item">
                <div class="platform-name">{result['platform']}</div>
                <div class="platform-url"><a href="{result['url']}" target="_blank">{result['url']}</a></div>
            </div>
"""
        
        html_content += f"""
        </div>
    </div>
    
    <div class="section">
        <h2>❌ Not Found ({len(not_found_platforms)})</h2>
        <div class="platform-list">
"""
        
        for result in not_found_platforms:
            html_content += f"""
            <div class="platform-item not-found">
                <div class="platform-name">{result['platform']}</div>
                <div class="platform-url">{result['url']}</div>
            </div>
"""
        
        html_content += """
        </div>
    </div>
    
    <div class="footer">
        <p>Generated by OSINT Suite | All data collected from publicly available sources</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"username_{username}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {report_path}")
        return report_path
    
    def generate_email_report(self, email, data):
        """
        Generate HTML report for email OSINT
        
        Args:
            email: Email address analyzed
            data: Analysis results
        
        Returns:
            Path: Path to generated report
        """
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email OSINT Report - {email}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #f5576c;
            padding-bottom: 10px;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .info-item {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #f5576c;
        }}
        .info-label {{
            font-weight: bold;
            color: #666;
            margin-bottom: 5px;
        }}
        .info-value {{
            font-size: 18px;
            color: #333;
        }}
        .alert {{
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
        }}
        .alert-danger {{
            background-color: #f8d7da;
            border-left: 4px solid #dc3545;
            color: #721c24;
        }}
        .alert-success {{
            background-color: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }}
        .alert-warning {{
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            color: #856404;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📧 Email OSINT Report</h1>
        <p>Target Email: <strong>{email}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>Email Validation</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Format Valid</div>
                <div class="info-value">{'✅ Yes' if data.get('valid') else '❌ No'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Disposable Email</div>
                <div class="info-value">{'⚠️ Yes' if data.get('disposable') else '✅ No'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Domain</div>
                <div class="info-value">{email.split('@')[1] if '@' in email else 'N/A'}</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2>Breach Status</h2>
"""
        
        if data.get('breached'):
            html_content += f"""
        <div class="alert alert-danger">
            <strong>⚠️ WARNING:</strong> This email has been found in {data.get('breach_count', 0)} data breach(es)!
        </div>
        <p>This email address has appeared in known data breaches. The account holder should:</p>
        <ul>
            <li>Change passwords immediately</li>
            <li>Enable two-factor authentication</li>
            <li>Monitor for suspicious activity</li>
        </ul>
"""
        else:
            html_content += """
        <div class="alert alert-success">
            <strong>✅ GOOD NEWS:</strong> This email has not been found in any known data breaches.
        </div>
"""
        
        html_content += """
    </div>
    
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | Data from publicly available breach databases</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"email_{email.replace('@', '_at_')}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {report_path}")
        return report_path
    
    def convert_to_pdf(self, html_path: Path) -> Path:
        """
        Convert HTML report to PDF
        
        Args:
            html_path: Path to HTML file
        
        Returns:
            Path: Path to generated PDF file
        """
        if not PDF_SUPPORT:
            logger.warning("PDF generation not available - WeasyPrint not installed")
            return None
        
        try:
            pdf_path = html_path.with_suffix('.pdf')
            HTML(str(html_path)).write_pdf(str(pdf_path))
            logger.info(f"PDF report generated: {pdf_path}")
            return pdf_path
        except Exception as e:
            logger.error(f"Error generating PDF: {e}")
            return None
    
    def generate_phone_report(self, phone: str, data: dict) -> Path:
        """Generate report for phone number OSINT"""
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Phone Number OSINT Report - {phone}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .info-item {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #4facfe;
        }}
        .info-label {{
            font-weight: bold;
            color: #666;
            margin-bottom: 5px;
        }}
        .info-value {{
            font-size: 18px;
            color: #333;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📱 Phone Number OSINT Report</h1>
        <p>Target Number: <strong>{phone}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>Number Information</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Formatted</div>
                <div class="info-value">{data.get('info', {}).get('formatted', phone)}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Country</div>
                <div class="info-value">{data.get('info', {}).get('country_code', {}).get('country', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Type</div>
                <div class="info-value">{data.get('info', {}).get('number_type', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Carrier</div>
                <div class="info-value">{data.get('info', {}).get('carrier', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Location</div>
                <div class="info-value">{data.get('info', {}).get('location', 'Unknown')}</div>
            </div>
        </div>
    </div>
    
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | Phone data analysis</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"phone_{phone.replace('+', '').replace(' ', '_')}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Phone report generated: {report_path}")
        return report_path
    
    def generate_ip_report(self, ip: str, data: dict) -> Path:
        """Generate report for IP geolocation"""
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>IP Geolocation Report - {ip}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .info-item {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border-left: 4px solid #43e97b;
        }}
        .map {{
            width: 100%;
            height: 400px;
            border-radius: 10px;
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🌐 IP Geolocation Report</h1>
        <p>IP Address: <strong>{ip}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>Location Information</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Country</div>
                <div class="info-value">{data.get('info', {}).get('country', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Region</div>
                <div class="info-value">{data.get('info', {}).get('region', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">City</div>
                <div class="info-value">{data.get('info', {}).get('city', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Timezone</div>
                <div class="info-value">{data.get('info', {}).get('timezone', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">ISP</div>
                <div class="info-value">{data.get('info', {}).get('isp', 'Unknown')}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Organization</div>
                <div class="info-value">{data.get('info', {}).get('organization', 'Unknown')}</div>
            </div>
        </div>
        
        {f'<iframe class="map" src="{data.get("info", {}).get("maps_url", "")}" frameborder="0"></iframe>' if data.get('info', {}).get('maps_url') else ''}
    </div>
    
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | IP Geolocation Analysis</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"ip_{ip.replace('.', '_')}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"IP report generated: {report_path}")
        return report_path
    
    def generate_blockchain_report(self, address: str, data: dict) -> Path:
        """Generate report for blockchain address tracking"""
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Blockchain Address Report - {address[:10]}...</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .address {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            word-break: break-all;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>₿ Blockchain Address Report</h1>
        <p>Type: <strong>{data.get('type', 'Unknown').upper()}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="section">
        <h2>Address</h2>
        <div class="address">{address}</div>
    </div>
    
    <div class="section">
        <h2>Balance & Transactions</h2>
        {f"<p>Balance: <strong>{data.get('info', {}).get('final_balance', 0)} BTC</strong></p>" if data.get('info', {}).get('final_balance') else ""}
        {f"<p>Total Received: {data.get('info', {}).get('total_received', 0)} BTC</p>" if data.get('info', {}).get('total_received') else ""}
        {f"<p>Total Sent: {data.get('info', {}).get('total_sent', 0)} BTC</p>" if data.get('info', {}).get('total_sent') else ""}
        {f"<p>Total Transactions: {data.get('info', {}).get('total_transactions', 0)}</p>" if data.get('info', {}).get('total_transactions') else ""}
    </div>
    
    <div class="section">
        <h2>Explorer Links</h2>
        <ul>
        {"".join([f'<li><a href="{url}" target="_blank">{name}</a></li>' for name, url in data.get('explorer_links', {}).items()])}
        </ul>
    </div>
    
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | Blockchain Analysis</p>
    </div>
</body>
</html>
"""
        
        addr_short = address[:10] + '_' + address[-6:]
        report_path = REPORTS_DIR / f"blockchain_{addr_short}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Blockchain report generated: {report_path}")
        return report_path
    
    def generate_social_stalker_report(self, username: str, data: dict) -> Path:
        """Generate report for social media stalking"""
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Social Media Stalking Report - {username}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .section {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .profile-card {{
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin: 15px 0;
        }}
        .platform-badge {{
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            color: white;
            font-weight: bold;
            margin-bottom: 10px;
        }}
        .tiktok {{ background: #000; }}
        .instagram {{ background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        .stat {{
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }}
        .stat-number {{
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
        }}
        .stat-label {{
            color: #666;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>👁️ Social Media Stalking Report</h1>
        <p>Target Username: <strong>@{username}</strong></p>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
"""
        
        # Add platform profiles
        for platform, profile_data in data.get('platforms', {}).items():
            if profile_data.get('success'):
                profile = profile_data.get('profile', {})
                html_content += f"""
    <div class="section">
        <span class="platform-badge {platform}">{platform.upper()}</span>
        <div class="profile-card">
            <h2>@{profile.get('username', username)}</h2>
            <p><strong>{profile.get('nickname') or profile.get('full_name', '')}</strong></p>
            <p>{profile.get('bio', 'No bio available')}</p>
            <p>✓ Verified: {'Yes' if profile.get('verified') else 'No'} | 
               🔒 Private: {'Yes' if profile.get('private') else 'No'}</p>
            
            <div class="stats">
                <div class="stat">
                    <div class="stat-number">{profile.get('followers', 0):,}</div>
                    <div class="stat-label">Followers</div>
                </div>
                <div class="stat">
                    <div class="stat-number">{profile.get('following', 0):,}</div>
                    <div class="stat-label">Following</div>
                </div>
                <div class="stat">
                    <div class="stat-number">{profile.get('total_videos') or profile.get('posts', 0):,}</div>
                    <div class="stat-label">Posts</div>
                </div>
                {f'<div class="stat"><div class="stat-number">{profile.get("total_likes", 0):,}</div><div class="stat-label">Total Likes</div></div>' if profile.get('total_likes') else ''}
            </div>
            
            <p style="margin-top: 15px;">
                <a href="{profile.get('profile_url', '')}" target="_blank">View Profile →</a>
            </p>
        </div>
    </div>
"""
        
        html_content += """
    <div class="footer" style="text-align: center; padding: 20px; color: #666;">
        <p>Generated by OSINT Suite | Social Media Intelligence</p>
    </div>
</body>
</html>
"""
        
        report_path = REPORTS_DIR / f"social_stalker_{username}_{self.timestamp}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Social stalker report generated: {report_path}")
        return report_path

