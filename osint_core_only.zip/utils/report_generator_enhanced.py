"""
Enhanced Report Generator for OSINT Suite
Generates professional HTML and PDF reports for all modules
"""

from datetime import datetime
from pathlib import Path
from typing import Dict, Optional
from config import REPORTS_DIR
from utils.logger import setup_logger
import json

logger = setup_logger(__name__)

# PDF generation support
try:
    from weasyprint import HTML, CSS
    from weasyprint.text.fonts import FontConfiguration
    PDF_SUPPORT = True
    logger.info("PDF support enabled (WeasyPrint)")
except ImportError:
    PDF_SUPPORT = False
    logger.warning("WeasyPrint not installed - PDF generation disabled")

# Alternative PDF support using ReportLab
try:
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    REPORTLAB_SUPPORT = True
    logger.info("Alternative PDF support enabled (ReportLab)")
except ImportError:
    REPORTLAB_SUPPORT = False
    logger.warning("ReportLab not installed - Alternative PDF generation disabled")


class EnhancedReportGenerator:
    """Generate comprehensive HTML and PDF reports for OSINT results"""
    
    def __init__(self):
        """Initialize report generator with timestamp"""
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.reports_dir = Path(REPORTS_DIR)
        self.reports_dir.mkdir(exist_ok=True)
        
    def get_common_css(self):
        """Get common CSS for all reports"""
        return """
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 15px;
                box-shadow: 0 10px 50px rgba(0,0,0,0.2);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 40px;
                text-align: center;
            }
            
            .header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            
            .header .subtitle {
                font-size: 1.2em;
                opacity: 0.9;
            }
            
            .content {
                padding: 40px;
            }
            
            .section {
                margin-bottom: 40px;
                padding: 25px;
                background: #f8f9fa;
                border-radius: 10px;
                border-left: 5px solid #667eea;
            }
            
            .section h2 {
                color: #667eea;
                margin-bottom: 20px;
                font-size: 1.8em;
                display: flex;
                align-items: center;
            }
            
            .section h2::before {
                content: '';
                display: inline-block;
                width: 8px;
                height: 30px;
                background: #764ba2;
                margin-right: 15px;
                border-radius: 4px;
            }
            
            .info-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            
            .info-card {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                transition: transform 0.3s ease;
            }
            
            .info-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 5px 20px rgba(102, 126, 234, 0.3);
            }
            
            .info-label {
                font-weight: bold;
                color: #667eea;
                margin-bottom: 8px;
                font-size: 0.9em;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            
            .info-value {
                font-size: 1.2em;
                color: #333;
                word-wrap: break-word;
            }
            
            .badge {
                display: inline-block;
                padding: 5px 15px;
                border-radius: 20px;
                font-size: 0.9em;
                font-weight: bold;
                margin: 5px;
            }
            
            .badge-success {
                background: #d4edda;
                color: #155724;
            }
            
            .badge-danger {
                background: #f8d7da;
                color: #721c24;
            }
            
            .badge-warning {
                background: #fff3cd;
                color: #856404;
            }
            
            .badge-info {
                background: #d1ecf1;
                color: #0c5460;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
                background: white;
                border-radius: 10px;
                overflow: hidden;
            }
            
            th {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 15px;
                text-align: left;
                font-weight: 600;
            }
            
            td {
                padding: 12px 15px;
                border-bottom: 1px solid #e9ecef;
            }
            
            tr:hover {
                background: #f8f9fa;
            }
            
            .alert {
                padding: 15px 20px;
                border-radius: 8px;
                margin: 15px 0;
            }
            
            .alert-success {
                background: #d4edda;
                border-left: 4px solid #28a745;
                color: #155724;
            }
            
            .alert-danger {
                background: #f8d7da;
                border-left: 4px solid #dc3545;
                color: #721c24;
            }
            
            .alert-warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                color: #856404;
            }
            
            .alert-info {
                background: #d1ecf1;
                border-left: 4px solid #17a2b8;
                color: #0c5460;
            }
            
            .footer {
                background: #2c3e50;
                color: #ecf0f1;
                padding: 30px;
                text-align: center;
            }
            
            .footer p {
                margin: 10px 0;
            }
            
            .link-button {
                display: inline-block;
                padding: 10px 20px;
                background: #667eea;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                margin: 5px;
                transition: background 0.3s ease;
            }
            
            .link-button:hover {
                background: #764ba2;
            }
            
            @media print {
                body {
                    background: white;
                    padding: 0;
                }
                
                .container {
                    box-shadow: none;
                }
                
                .info-card:hover {
                    transform: none;
                }
            }
        </style>
        """
    
    def generate_phone_report(self, phone: str, results: Dict, format='html') -> str:
        """Generate phone OSINT report"""
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phone OSINT Report - {phone}</title>
    {self.get_common_css()}
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📱 Phone Number OSINT Report</h1>
            <div class="subtitle">Intelligence Report for: {phone}</div>
            <div class="subtitle">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        </div>
        
        <div class="content">
            <!-- Validation Status -->
            <div class="section">
                <h2>Validation Status</h2>
                {'<div class="alert alert-success">✅ Phone number is valid</div>' if results.get('valid') else '<div class="alert alert-danger">❌ Phone number is invalid</div>'}
            </div>
            
            <!-- Basic Information -->
            <div class="section">
                <h2>Basic Information</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">Phone Number</div>
                        <div class="info-value">{results.get('number', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Country</div>
                        <div class="info-value">{results.get('info', {}).get('country_code', {}).get('country', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Country Code</div>
                        <div class="info-value">{results.get('info', {}).get('country_code', {}).get('code', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Number Type</div>
                        <div class="info-value">{results.get('info', {}).get('number_type', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Carrier</div>
                        <div class="info-value">{results.get('info', {}).get('carrier', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Location</div>
                        <div class="info-value">{results.get('info', {}).get('location', 'N/A')}</div>
                    </div>
                </div>
            </div>
            
            <!-- Formatted Numbers -->
            {self._generate_formatted_numbers_section(results)}
            
            <!-- Timezone Information -->
            {self._generate_timezone_section(results)}
            
            <!-- Social Media Links -->
            {self._generate_social_media_section(results)}
            
            <!-- Advanced Information -->
            {self._generate_advanced_info_section(results)}
        </div>
        
        <div class="footer">
            <p><strong>OWL OSINT Suite</strong></p>
            <p>Professional Open Source Intelligence Tool</p>
            <p>Report generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</p>
        </div>
    </div>
</body>
</html>"""
        
        # Save HTML report
        filename = f'phone_report_{phone.replace("+", "").replace(" ", "")}_{self.timestamp}.html'
        filepath = self.reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Phone report generated: {filepath}")
        
        # Generate PDF if requested and available
        if format == 'pdf' and PDF_SUPPORT:
            pdf_path = self._convert_to_pdf(filepath)
            return pdf_path
        elif format == 'pdf' and REPORTLAB_SUPPORT:
            pdf_path = self._generate_pdf_reportlab(phone, results, 'phone')
            return pdf_path
        
        return str(filepath)
    
    def generate_ip_report(self, ip: str, results: Dict, format='html') -> str:
        """Generate IP geolocation report"""
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Geolocation Report - {ip}</title>
    {self.get_common_css()}
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🌐 IP Address Geolocation Report</h1>
            <div class="subtitle">Intelligence Report for: {ip}</div>
            <div class="subtitle">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        </div>
        
        <div class="content">
            <!-- Validation Status -->
            <div class="section">
                <h2>Validation Status</h2>
                {'<div class="alert alert-success">✅ IP address is valid</div>' if results.get('valid') else '<div class="alert alert-danger">❌ IP address is invalid</div>'}
            </div>
            
            <!-- Location Information -->
            <div class="section">
                <h2>Location Information</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">IP Address</div>
                        <div class="info-value">{ip}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Country</div>
                        <div class="info-value">{results.get('info', {}).get('country', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Country Code</div>
                        <div class="info-value">{results.get('info', {}).get('country_code', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Region</div>
                        <div class="info-value">{results.get('info', {}).get('region', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">City</div>
                        <div class="info-value">{results.get('info', {}).get('city', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">ZIP Code</div>
                        <div class="info-value">{results.get('info', {}).get('zip', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Latitude</div>
                        <div class="info-value">{results.get('info', {}).get('latitude', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Longitude</div>
                        <div class="info-value">{results.get('info', {}).get('longitude', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Timezone</div>
                        <div class="info-value">{results.get('info', {}).get('timezone', 'N/A')}</div>
                    </div>
                </div>
            </div>
            
            <!-- Network Information -->
            <div class="section">
                <h2>Network Information</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">ISP</div>
                        <div class="info-value">{results.get('info', {}).get('isp', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Organization</div>
                        <div class="info-value">{results.get('info', {}).get('organization', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">AS Number</div>
                        <div class="info-value">{results.get('info', {}).get('as', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Reverse DNS</div>
                        <div class="info-value">{results.get('info', {}).get('reverse_dns', 'N/A')}</div>
                    </div>
                </div>
            </div>
            
            <!-- Security Flags -->
            <div class="section">
                <h2>Security Analysis</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">Mobile Connection</div>
                        <div class="info-value">
                            {'✅ Yes' if results.get('info', {}).get('mobile') else '❌ No'}
                        </div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Proxy Detected</div>
                        <div class="info-value">
                            {'⚠️ Yes' if results.get('info', {}).get('proxy') else '✅ No'}
                        </div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Hosting/Datacenter</div>
                        <div class="info-value">
                            {'⚠️ Yes' if results.get('info', {}).get('hosting') else '✅ No'}
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Map Link -->
            {self._generate_map_section(results)}
        </div>
        
        <div class="footer">
            <p><strong>OWL OSINT Suite</strong></p>
            <p>Professional Open Source Intelligence Tool</p>
            <p>Report generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</p>
        </div>
    </div>
</body>
</html>"""
        
        # Save HTML report
        filename = f'ip_report_{ip.replace(".", "_")}_{self.timestamp}.html'
        filepath = self.reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"IP report generated: {filepath}")
        
        # Generate PDF if requested
        if format == 'pdf' and PDF_SUPPORT:
            pdf_path = self._convert_to_pdf(filepath)
            return pdf_path
        elif format == 'pdf' and REPORTLAB_SUPPORT:
            pdf_path = self._generate_pdf_reportlab(ip, results, 'ip')
            return pdf_path
        
        return str(filepath)
    
    def generate_blockchain_report(self, address: str, results: Dict, format='html') -> str:
        """Generate blockchain tracking report"""
        
        crypto_type = results.get('detected_type', results.get('type', 'unknown'))
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blockchain Report - {address[:10]}...</title>
    {self.get_common_css()}
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>₿ Blockchain Address Tracking Report</h1>
            <div class="subtitle">Cryptocurrency: {crypto_type.upper()}</div>
            <div class="subtitle">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        </div>
        
        <div class="content">
            <!-- Address Information -->
            <div class="section">
                <h2>Address Information</h2>
                <div class="alert alert-info">
                    <strong>Address:</strong> {address}
                </div>
                <div class="alert {'alert-success' if results.get('success') else 'alert-warning'}">
                    {'✅ Successfully tracked address' if results.get('success') else '⚠️ Limited information available'}
                </div>
            </div>
            
            <!-- Balance & Transactions -->
            {self._generate_blockchain_balance_section(results)}
            
            <!-- Recent Transactions -->
            {self._generate_blockchain_transactions_section(results)}
            
            <!-- Explorer Links -->
            {self._generate_explorer_links_section(results)}
        </div>
        
        <div class="footer">
            <p><strong>OWL OSINT Suite</strong></p>
            <p>Professional Open Source Intelligence Tool</p>
            <p>Report generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</p>
        </div>
    </div>
</body>
</html>"""
        
        # Save HTML report
        filename = f'blockchain_report_{crypto_type}_{address[:10]}_{self.timestamp}.html'
        filepath = self.reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Blockchain report generated: {filepath}")
        
        # Generate PDF if requested
        if format == 'pdf' and PDF_SUPPORT:
            pdf_path = self._convert_to_pdf(filepath)
            return pdf_path
        elif format == 'pdf' and REPORTLAB_SUPPORT:
            pdf_path = self._generate_pdf_reportlab(address, results, 'blockchain')
            return pdf_path
        
        return str(filepath)
    
    def generate_social_stalker_report(self, username: str, results: Dict, format='html') -> str:
        """Generate social media stalking report"""
        
        platform = results.get('platform', 'multi')
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Media Report - @{username}</title>
    {self.get_common_css()}
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>👁️ Social Media Stalking Report</h1>
            <div class="subtitle">Username: @{username}</div>
            <div class="subtitle">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        </div>
        
        <div class="content">
            <!-- Profile Found Status -->
            <div class="section">
                <h2>Search Results</h2>
                {'<div class="alert alert-success">✅ Profile found!</div>' if results.get('success') else '<div class="alert alert-warning">⚠️ Profile not found or error occurred</div>'}
                {f'<div class="alert alert-danger">❌ Error: {results.get("error")}</div>' if results.get('error') else ''}
            </div>
            
            <!-- Profile Information -->
            {self._generate_social_profile_section(results)}
            
            <!-- Statistics -->
            {self._generate_social_stats_section(results)}
            
            <!-- Profile Links -->
            {self._generate_social_links_section(results)}
        </div>
        
        <div class="footer">
            <p><strong>OWL OSINT Suite</strong></p>
            <p>Professional Open Source Intelligence Tool</p>
            <p>Report generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</p>
        </div>
    </div>
</body>
</html>"""
        
        # Save HTML report
        filename = f'social_report_{platform}_{username}_{self.timestamp}.html'
        filepath = self.reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Social media report generated: {filepath}")
        
        # Generate PDF if requested
        if format == 'pdf' and PDF_SUPPORT:
            pdf_path = self._convert_to_pdf(filepath)
            return pdf_path
        elif format == 'pdf' and REPORTLAB_SUPPORT:
            pdf_path = self._generate_pdf_reportlab(username, results, 'social')
            return pdf_path
        
        return str(filepath)
    
    # Helper methods for generating sections
    def _generate_formatted_numbers_section(self, results: Dict) -> str:
        """Generate formatted numbers section for phone reports"""
        formatted = results.get('info', {}).get('formatted', {})
        
        if isinstance(formatted, dict):
            return f"""
            <div class="section">
                <h2>Formatted Numbers</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">International</div>
                        <div class="info-value">{formatted.get('international', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">National</div>
                        <div class="info-value">{formatted.get('national', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">E.164</div>
                        <div class="info-value">{formatted.get('e164', 'N/A')}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">RFC3966</div>
                        <div class="info-value">{formatted.get('rfc3966', 'N/A')}</div>
                    </div>
                </div>
            </div>
            """
        return ""
    
    def _generate_timezone_section(self, results: Dict) -> str:
        """Generate timezone section for phone reports"""
        timezones = results.get('info', {}).get('timezones', [])
        
        if timezones and timezones[0] != 'Unknown':
            tz_list = ', '.join(timezones)
            return f"""
            <div class="section">
                <h2>Timezone Information</h2>
                <div class="info-card">
                    <div class="info-label">Timezones</div>
                    <div class="info-value">{tz_list}</div>
                </div>
            </div>
            """
        return ""
    
    def _generate_social_media_section(self, results: Dict) -> str:
        """Generate social media links section"""
        social = results.get('social_media', {})
        
        if not social:
            return ""
        
        links_html = ""
        for platform, info in social.items():
            if platform == 'note':
                continue
            if isinstance(info, dict):
                url = info.get('url', info.get('check_url', '#'))
                note = info.get('note', '')
                links_html += f'<a href="{url}" class="link-button" target="_blank">{platform.upper()}</a>'
        
        if links_html:
            return f"""
            <div class="section">
                <h2>Social Media Presence</h2>
                <p>Click links below to check if this number is registered on various platforms:</p>
                <div style="margin-top: 15px;">
                    {links_html}
                </div>
                <div class="alert alert-info" style="margin-top: 15px;">
                    ℹ️ Manual verification may be required for some platforms
                </div>
            </div>
            """
        return ""
    
    def _generate_advanced_info_section(self, results: Dict) -> str:
        """Generate advanced information section"""
        advanced = results.get('advanced_info', {})
        
        if not advanced:
            return ""
        
        spam_check = advanced.get('spam_check', {})
        
        if spam_check.get('checked'):
            spam_html = f"""
            <div class="section">
                <h2>Spam Analysis</h2>
                <div class="alert {'alert-danger' if spam_check.get('is_spam') else 'alert-success'}">
                    {'🚨 WARNING: This number has been reported as spam!' if spam_check.get('is_spam') else '✅ No spam reports found'}
                </div>
                {f"<p>Reports: {spam_check.get('reports', 0)}</p>" if spam_check.get('is_spam') else ''}
                <p style="font-size: 0.9em; color: #666;">{spam_check.get('note', '')}</p>
            </div>
            """
            return spam_html
        
        return ""
    
    def _generate_map_section(self, results: Dict) -> str:
        """Generate map section for IP reports"""
        maps_url = results.get('info', {}).get('maps_url')
        
        if maps_url:
            return f"""
            <div class="section">
                <h2>Location Map</h2>
                <a href="{maps_url}" class="link-button" target="_blank">🗺️ View on Google Maps</a>
            </div>
            """
        return ""
    
    def _generate_blockchain_balance_section(self, results: Dict) -> str:
        """Generate blockchain balance section"""
        info = results.get('info', {})
        
        if not info:
            return ""
        
        balance_html = ""
        if 'final_balance' in info or 'balance' in info:
            balance = info.get('final_balance', info.get('balance', 0))
            total_received = info.get('total_received', 0)
            total_sent = info.get('total_sent', 0)
            n_tx = info.get('total_transactions', info.get('n_tx', 0))
            
            balance_html = f"""
            <div class="section">
                <h2>Balance & Activity</h2>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-label">Current Balance</div>
                        <div class="info-value">{balance:,.8f} {results.get('type', 'crypto').upper()}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Total Received</div>
                        <div class="info-value">{total_received:,.8f}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Total Sent</div>
                        <div class="info-value">{total_sent:,.8f}</div>
                    </div>
                    <div class="info-card">
                        <div class="info-label">Total Transactions</div>
                        <div class="info-value">{n_tx:,}</div>
                    </div>
                </div>
            </div>
            """
        
        return balance_html
    
    def _generate_blockchain_transactions_section(self, results: Dict) -> str:
        """Generate recent transactions section"""
        transactions = results.get('recent_transactions', [])
        
        if not transactions:
            return ""
        
        tx_rows = ""
        for tx in transactions[:10]:
            if isinstance(tx, dict):
                tx_hash = tx.get('hash', tx.get('txid', 'N/A'))[:16] + '...'
                tx_time = tx.get('time', tx.get('timestamp', 'N/A'))
                block = tx.get('block_height', tx.get('block', 'N/A'))
                
                tx_rows += f"""
                <tr>
                    <td>{tx_hash}</td>
                    <td>{tx_time}</td>
                    <td>{block}</td>
                </tr>
                """
        
        if tx_rows:
            return f"""
            <div class="section">
                <h2>Recent Transactions</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Transaction Hash</th>
                            <th>Time</th>
                            <th>Block</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tx_rows}
                    </tbody>
                </table>
            </div>
            """
        
        return ""
    
    def _generate_explorer_links_section(self, results: Dict) -> str:
        """Generate blockchain explorer links section"""
        explorer_links = results.get('explorer_links', {})
        
        if not explorer_links:
            return ""
        
        links_html = ""
        for name, url in explorer_links.items():
            display_name = name.replace('_', ' ').title()
            links_html += f'<a href="{url}" class="link-button" target="_blank">{display_name}</a>'
        
        if links_html:
            return f"""
            <div class="section">
                <h2>Blockchain Explorers</h2>
                <p>View this address on various blockchain explorers:</p>
                <div style="margin-top: 15px;">
                    {links_html}
                </div>
            </div>
            """
        
        return ""
    
    def _generate_social_profile_section(self, results: Dict) -> str:
        """Generate social media profile section"""
        profile = results.get('profile', {})
        
        if not profile:
            return ""
        
        username = profile.get('username', 'N/A')
        full_name = profile.get('nickname', profile.get('full_name', 'N/A'))
        bio = profile.get('bio', 'No bio available')
        verified = '✅ Verified' if profile.get('verified') else '❌ Not Verified'
        private = '🔒 Private' if profile.get('private') else '🔓 Public'
        
        return f"""
        <div class="section">
            <h2>Profile Information</h2>
            <div class="info-grid">
                <div class="info-card">
                    <div class="info-label">Username</div>
                    <div class="info-value">@{username}</div>
                </div>
                <div class="info-card">
                    <div class="info-label">Name</div>
                    <div class="info-value">{full_name}</div>
                </div>
                <div class="info-card">
                    <div class="info-label">Verification Status</div>
                    <div class="info-value">{verified}</div>
                </div>
                <div class="info-card">
                    <div class="info-label">Account Privacy</div>
                    <div class="info-value">{private}</div>
                </div>
            </div>
            <div class="alert alert-info" style="margin-top: 20px;">
                <strong>Bio:</strong><br>{bio}
            </div>
        </div>
        """
    
    def _generate_social_stats_section(self, results: Dict) -> str:
        """Generate social media statistics section"""
        profile = results.get('profile', {})
        
        if not profile:
            return ""
        
        followers = profile.get('followers', 0)
        following = profile.get('following', 0)
        posts = profile.get('total_videos', profile.get('posts', 0))
        likes = profile.get('total_likes')
        
        stats_html = f"""
        <div class="section">
            <h2>Account Statistics</h2>
            <div class="info-grid">
                <div class="info-card">
                    <div class="info-label">Followers</div>
                    <div class="info-value">{followers:,}</div>
                </div>
                <div class="info-card">
                    <div class="info-label">Following</div>
                    <div class="info-value">{following:,}</div>
                </div>
                <div class="info-card">
                    <div class="info-label">Posts/Videos</div>
                    <div class="info-value">{posts:,}</div>
                </div>
        """
        
        if likes:
            stats_html += f"""
                <div class="info-card">
                    <div class="info-label">Total Likes</div>
                    <div class="info-value">{likes:,}</div>
                </div>
            """
        
        stats_html += """
            </div>
        </div>
        """
        
        return stats_html
    
    def _generate_social_links_section(self, results: Dict) -> str:
        """Generate social media profile links section"""
        profile = results.get('profile', {})
        
        profile_url = profile.get('profile_url')
        external_url = profile.get('external_url')
        avatar = profile.get('avatar', profile.get('profile_pic'))
        
        if not profile_url:
            return ""
        
        links_html = f'<a href="{profile_url}" class="link-button" target="_blank">View Profile</a>'
        
        if external_url:
            links_html += f'<a href="{external_url}" class="link-button" target="_blank">External Link</a>'
        
        section_html = f"""
        <div class="section">
            <h2>Profile Links</h2>
            <div style="margin-top: 15px;">
                {links_html}
            </div>
        </div>
        """
        
        if avatar:
            section_html = f"""
            <div class="section">
                <h2>Profile Picture</h2>
                <img src="{avatar}" alt="Profile Picture" style="max-width: 200px; border-radius: 50%; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
            </div>
            """ + section_html
        
        return section_html
    
    def _convert_to_pdf(self, html_path: Path) -> str:
        """Convert HTML report to PDF using WeasyPrint"""
        try:
            pdf_path = html_path.with_suffix('.pdf')
            
            font_config = FontConfiguration()
            html = HTML(filename=str(html_path))
            html.write_pdf(pdf_path, font_config=font_config)
            
            logger.info(f"PDF report generated: {pdf_path}")
            return str(pdf_path)
        except Exception as e:
            logger.error(f"Error converting to PDF: {e}")
            return str(html_path)
    
    def _generate_pdf_reportlab(self, subject: str, results: Dict, report_type: str) -> str:
        """Generate PDF using ReportLab (fallback method)"""
        try:
            filename = f'{report_type}_report_{subject[:20]}_{self.timestamp}.pdf'
            filepath = self.reports_dir / filename
            
            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            story = []
            styles = getSampleStyleSheet()
            
            # Add title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#667eea'),
                spaceAfter=30,
                alignment=TA_CENTER
            )
            
            title = Paragraph(f"{report_type.upper()} OSINT Report", title_style)
            story.append(title)
            story.append(Spacer(1, 12))
            
            # Add subject
            subject_para = Paragraph(f"<b>Subject:</b> {subject}", styles['Normal'])
            story.append(subject_para)
            story.append(Spacer(1, 12))
            
            # Add timestamp
            timestamp_para = Paragraph(
                f"<b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                styles['Normal']
            )
            story.append(timestamp_para)
            story.append(Spacer(1, 20))
            
            # Add results as table
            if results.get('info'):
                data = [['Property', 'Value']]
                for key, value in results['info'].items():
                    if isinstance(value, dict):
                        value = str(value)
                    data.append([str(key).replace('_', ' ').title(), str(value)])
                
                t = Table(data, colWidths=[2*inch, 4*inch])
                t.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#667eea')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 14),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(t)
            
            # Build PDF
            doc.build(story)
            logger.info(f"PDF report (ReportLab) generated: {filepath}")
            return str(filepath)
            
        except Exception as e:
            logger.error(f"Error generating PDF with ReportLab: {e}")
            return ""
