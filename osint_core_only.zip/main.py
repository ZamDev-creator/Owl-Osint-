#!/usr/bin/env python3
"""
OSINT Multi-Tool Suite
A comprehensive OSINT toolkit with interactive CLI

Main entry point for the application
"""

import asyncio
import sys
import os
from pathlib import Path
from typing import Optional

# Import UI libraries
import pyfiglet
from termcolor import colored
import questionary
from tabulate import tabulate

# Import modules
from modules.username_hunter import UsernameHunter
from modules.email_osint import EmailOSINT
from modules.image_metadata import ImageMetadata
from modules.change_monitor import ChangeMonitor
from utils.report_generator import ReportGenerator
from utils.logger import setup_logger
from config import OUTPUT_DIR, SCREENSHOTS_DIR

logger = setup_logger(__name__)

# ANSI Color Codes for custom banner
PURPLE = '\033[38;5;93m'
BRIGHT_PURPLE = '\033[38;5;129m'
DARK_PURPLE = '\033[38;5;54m'
LIGHT_PURPLE = '\033[38;5;141m'
CYAN = '\033[38;5;51m'
BRIGHT_CYAN = '\033[38;5;87m'
GRAY = '\033[38;5;245m'
DARK_GRAY = '\033[38;5;237m'
RESET = '\033[0m'


class OSINTSuite:
    """Main OSINT Suite application class"""
    
    def __init__(self):
        """Initialize all OSINT modules"""
        try:
            self.username_hunter = UsernameHunter()
            self.email_osint = EmailOSINT()
            self.image_metadata = ImageMetadata()
            self.change_monitor = ChangeMonitor()
            self.report_gen = ReportGenerator()
            logger.info("OSINT Suite initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize OSINT Suite: {e}")
            raise
    
    def print_banner(self):
        """Print custom OWL ASCII banner with purple/blue theme"""
        banner = f"""
{DARK_PURPLE}╔═══════════════════════════════════════════════════════════════════════════╗
║{RESET}                                                                           {DARK_PURPLE}║
║{BRIGHT_PURPLE}                        .#@@@@@@@@@@@@@@@#.                            {DARK_PURPLE}║
║{BRIGHT_PURPLE}                    *@@@@@@@@@@@@@@@@@@@@@@@*                        {DARK_PURPLE}║
║{BRIGHT_PURPLE}                  #@@@@@@@@@@@@@@@@@@@@@@@@@@@#                      {DARK_PURPLE}║
║{LIGHT_PURPLE}                *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*                    {DARK_PURPLE}║
║{LIGHT_PURPLE}               @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                   {DARK_PURPLE}║
║{PURPLE}              @@@@@#*.             .             .*#@@@@@              {DARK_PURPLE}║
║{PURPLE}            .@@@@*.   .-=#@@@@=.   .   .=@@@@#=-.   .*@@@@.            {DARK_PURPLE}║
║{PURPLE}            @@@*.   .#@@@@@@@@@@@. . .@@@@@@@@@@@#.   .*@@@            {DARK_PURPLE}║
║{BRIGHT_PURPLE}           #@@*   .@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@. .@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@.   *@@#           {DARK_PURPLE}║
║{BRIGHT_PURPLE}          .@@#   *@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@.@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@*   #@@.          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          *@@.  .@@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@@.  .@@*          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          @@@   #@@@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@@@#   @@@          {DARK_PURPLE}║
║{PURPLE}          @@@.  =@@@@@@@@@@@@@@*.{BRIGHT_CYAN}###.{PURPLE}*@@@@@@@@@@@@@@=  .@@@          {DARK_PURPLE}║
║{PURPLE}          #@@*   -@@@@@@@@@@@@@#.{BRIGHT_CYAN}###.{PURPLE}#@@@@@@@@@@@@@-   *@@#          {DARK_PURPLE}║
║{PURPLE}           @@@=    -*@@@@@@@@@@@#{BRIGHT_CYAN}####{PURPLE}#@@@@@@@@@@@*-    =@@@           {DARK_PURPLE}║
║{LIGHT_PURPLE}           *@@@#.     .=*#@@@@@@@@@@@@@@@@@#*=.     .#@@@*           {DARK_PURPLE}║
║{LIGHT_PURPLE}            .@@@@*.          :#{CYAN}#######{LIGHT_PURPLE}#:          .*@@@@.            {DARK_PURPLE}║
║{BRIGHT_PURPLE}              -@@@@@*:         {CYAN}########{BRIGHT_PURPLE}         :*@@@@@-              {DARK_PURPLE}║
║{BRIGHT_PURPLE}                :#@@@@#=:     {CYAN}#$#$#$#${BRIGHT_PURPLE}     :=#@@@@#:                {DARK_PURPLE}║
║{PURPLE}              .:**#@@@@@@@@@*:{CYAN}#$#$#$#${PURPLE}:*@@@@@@@@@#**:.              {DARK_PURPLE}║
║{PURPLE}            -*@@@@@@@@@@@@@@@#{CYAN}$#$#$#${PURPLE}#@@@@@@@@@@@@@@@*-            {DARK_PURPLE}║
║{PURPLE}           =@@@@@%{CYAN}*=---=*{PURPLE}%@@@@@#{CYAN}#$#$#{PURPLE}#@@@@@%{CYAN}*=---=*{PURPLE}%@@@@@=           {DARK_PURPLE}║
║{LIGHT_PURPLE}          *@@@@%{CYAN}=:     :={LIGHT_PURPLE}%@@@@#{CYAN}####{LIGHT_PURPLE}#@@@@%{CYAN}=:     :={LIGHT_PURPLE}%@@@@*          {DARK_PURPLE}║
║{LIGHT_PURPLE}          #@@@%{CYAN}-        -{LIGHT_PURPLE}%@@@@@@@@@@@@@%{CYAN}-        -{LIGHT_PURPLE}%@@@#          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          *@@@%{CYAN}=.      .={BRIGHT_PURPLE}%@@@@@@@@@@@@@%{CYAN}=.      .={BRIGHT_PURPLE}%@@@*          {DARK_PURPLE}║
║{BRIGHT_PURPLE}           @@@@@%{CYAN}*====*{BRIGHT_PURPLE}%@@@@@@@@@@@@@@@@%{CYAN}*====*{BRIGHT_PURPLE}%@@@@@           {DARK_PURPLE}║
║{PURPLE}            =@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=            {DARK_PURPLE}║
║{PURPLE}              -*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-              {DARK_PURPLE}║
║{DARK_PURPLE}                 .=*#@@@@@@@@@@@@@@@@@@#*=.                     ║
║{DARK_PURPLE}                       .:=*########*=:.                          ║
║{RESET}                                                                           {DARK_PURPLE}║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║{BRIGHT_PURPLE}    ███████╗ ██╗    ██╗ ██╗                                          {DARK_PURPLE}║
║{BRIGHT_PURPLE}   ██╔═══██╗ ██║    ██║ ██║          {BRIGHT_CYAN}  ███████╗  ██████╗ ██╗███╗  ██╗████████╗{DARK_PURPLE}║
║{PURPLE}   ██║   ██║ ██║ █╗ ██║ ██║          {CYAN} ██╔═══██╗██╔════╝ ██║████╗ ██║╚══██╔══╝{DARK_PURPLE}║
║{PURPLE}   ██║   ██║ ██║███╗██║ ██║          {CYAN} ██║   ██║╚█████╗  ██║██╔██╗██║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}   ██║   ██║ ██║╚██╔╝██║ ██║          {CYAN} ██║   ██║ ╚═══██╗ ██║██║╚████║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}   ╚██████╔╝ ╚███╔███╔╝ ███████╗      ╚██████╔╝██████╔╝ ██║██║ ╚███║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}    ╚═════╝   ╚══╝╚══╝  ╚══════╝       ╚═════╝ ╚═════╝  ╚═╝╚═╝  ╚══╝   ╚═╝   {DARK_PURPLE}║
║                                                                           ║
║{CYAN}        ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓        {DARK_PURPLE}║
║{CYAN}        ┃   {BRIGHT_CYAN}Open Source Intelligence Framework{CYAN}           ┃        {DARK_PURPLE}║
║{BRIGHT_CYAN}        ┃   {CYAN}Advanced Reconnaissance & Analysis Suite{BRIGHT_CYAN}      ┃        {DARK_PURPLE}║
║{CYAN}        ┃   {BRIGHT_CYAN}Professional Edition v2.0 - 2025{CYAN}                ┃        {DARK_PURPLE}║
║{CYAN}        ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛        {DARK_PURPLE}║
║                                                                           ║
║{PURPLE}     [{BRIGHT_PURPLE}$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$${PURPLE}]     {DARK_PURPLE}║
║{PURPLE}     [{BRIGHT_PURPLE}████████████████ SYSTEM READY ████████████████████████{PURPLE}]     {DARK_PURPLE}║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝{RESET}
"""
        print(banner)
    
    def clear_screen(self):
        """Clear terminal screen"""
        os.system('clear' if os.name != 'nt' else 'cls')
    
    def print_module_header(self, title: str):
        """Print module header with purple/blue theme"""
        print("\n" + colored("=" * 70, "magenta"))
        print(colored(f"  {title}", "magenta", attrs=["bold"]))
        print(colored("=" * 70, "magenta") + "\n")
    
    def username_search(self):
        """Username hunter module interface"""
        self.print_module_header("🔍 USERNAME HUNTER")
        
        username = questionary.text(
            "Enter username to search:",
            validate=lambda text: len(text) > 0 or "Username cannot be empty"
        ).ask()
        
        if not username:
            return
        
        print(colored(f"\n🔎 Hunting for '{username}' across platforms...\n", "cyan"))
        
        try:
            # Use asyncio.run() which properly manages event loop lifecycle
            results = asyncio.run(self.username_hunter.hunt(username))
            
            # Display results
            found = [r for r in results if r['found']]
            not_found = [r for r in results if not r['found']]
            
            print(colored(f"\n✅ FOUND ({len(found)} profiles):", "blue", attrs=["bold"]))
            if found:
                table_data = [[r['platform'], r['url']] for r in found]
                print(tabulate(table_data, headers=["Platform", "URL"], tablefmt="grid"))
            else:
                print("  No profiles found.")
            
            print(colored(f"\n❌ NOT FOUND ({len(not_found)} platforms):", "white"))
            if not_found:
                platforms_list = ", ".join([r['platform'] for r in not_found[:10]])
                if len(not_found) > 10:
                    platforms_list += f" ... and {len(not_found) - 10} more"
                print(f"  {platforms_list}")
            
            # Generate report
            generate_report = questionary.confirm("Generate HTML report?", default=True).ask()
            if generate_report:
                report_path = self.report_gen.generate_username_report(username, results)
                print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
        except Exception as e:
            logger.error(f"Error during username search: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def email_search(self):
        """Email OSINT module interface"""
        self.print_module_header("📧 EMAIL OSINT")
        
        email = questionary.text(
            "Enter email address to analyze:",
            validate=lambda text: '@' in text or "Invalid email format"
        ).ask()
        
        if not email:
            return
        
        print(colored(f"\n🔍 Analyzing '{email}'...\n", "cyan"))
        
        try:
            # Perform analysis
            results = self.email_osint.analyze(email)
            
            # Display results
            print(colored("📊 ANALYSIS RESULTS:", "cyan", attrs=["bold"]))
            print()
            
            status_icon = "✅" if results['valid'] else "❌"
            print(f"  {status_icon} Format Valid: {colored(str(results['valid']), 'blue' if results['valid'] else 'red')}")
            
            disp_icon = "⚠️" if results['disposable'] else "✅"
            disp_color = "yellow" if results['disposable'] else "blue"
            print(f"  {disp_icon} Disposable: {colored(str(results['disposable']), disp_color)}")
            
            if results['domain']:
                print(f"  🌐 Domain: {colored(results['domain'], 'cyan')}")
            
            print()
            print(colored("🔒 BREACH STATUS:", "cyan", attrs=["bold"]))
            
            if results['breached']:
                print(colored(f"  ⚠️ WARNING: Found in {results['breach_count']} breach(es)!", "red", attrs=["bold"]))
                print(colored("  → Recommendation: Change passwords immediately!", "yellow"))
            else:
                print(colored("  ✅ No breaches found", "blue"))
            
            # Generate report
            generate_report = questionary.confirm("\nGenerate HTML report?", default=True).ask()
            if generate_report:
                report_path = self.report_gen.generate_email_report(email, results)
                print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
        except Exception as e:
            logger.error(f"Error during email analysis: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def image_metadata_analysis(self):
        """Image metadata extractor module interface"""
        self.print_module_header("🖼️ IMAGE METADATA ANALYZER")
        
        image_path = questionary.path(
            "Enter path to image file:"
        ).ask()
        
        if not image_path:
            return
        
        # Check if file exists
        if not Path(image_path).exists():
            print(colored("❌ File not found!", "red"))
            self.wait_for_continue()
            return
        
        print(colored(f"\n📸 Extracting metadata from '{image_path}'...\n", "cyan"))
        
        try:
            # Extract metadata
            metadata = self.image_metadata.extract_metadata(image_path)
            
            # Basic info
            print(colored("📋 BASIC INFORMATION:", "cyan", attrs=["bold"]))
            basic_info = [
                ["File", metadata['filename']],
                ["Format", metadata['format'] or 'N/A'],
                ["Size", f"{metadata['file_size']:,} bytes" if metadata['file_size'] else 'N/A'],
                ["Dimensions", metadata['dimensions'] or 'N/A']
            ]
            print(tabulate(basic_info, tablefmt="grid"))
            
            # Camera info
            if metadata.get('camera_make') or metadata.get('camera_model'):
                print(colored("\n📷 CAMERA INFORMATION:", "cyan", attrs=["bold"]))
                camera_info = []
                if metadata.get('camera_make'):
                    camera_info.append(["Make", metadata['camera_make']])
                if metadata.get('camera_model'):
                    camera_info.append(["Model", metadata['camera_model']])
                if metadata.get('timestamp_taken'):
                    camera_info.append(["Date Taken", metadata['timestamp_taken']])
                print(tabulate(camera_info, tablefmt="grid"))
            
            # GPS data
            if metadata['latitude'] and metadata['longitude']:
                print(colored("\n📍 GPS LOCATION:", "cyan", attrs=["bold"]))
                gps_info = [
                    ["Latitude", f"{metadata['latitude']:.6f}"],
                    ["Longitude", f"{metadata['longitude']:.6f}"]
                ]
                if metadata['altitude']:
                    gps_info.append(["Altitude", f"{metadata['altitude']} m"])
                print(tabulate(gps_info, tablefmt="grid"))
                
                # Offer to open in Google Maps
                open_maps = questionary.confirm("Open location in Google Maps?", default=False).ask()
                if open_maps:
                    maps_url = f"https://www.google.com/maps?q={metadata['latitude']},{metadata['longitude']}"
                    print(colored(f"\n🗺️ Map URL: {maps_url}", "magenta"))
            else:
                print(colored("\n📍 No GPS data found in image", "white"))
            
            if metadata['all_exif']:
                show_all = questionary.confirm("\nShow all EXIF data?", default=False).ask()
                if show_all:
                    print(colored("\n📋 ALL EXIF DATA:", "cyan", attrs=["bold"]))
                    # Show ALL EXIF data without any limit
                    exif_data = [[k, v] for k, v in metadata['all_exif'].items()]
                    print(tabulate(exif_data, headers=["Tag", "Value"], tablefmt="grid"))
                    print(colored(f"\n✅ Total: {len(metadata['all_exif'])} EXIF tags displayed", "magenta"))
        except Exception as e:
            logger.error(f"Error extracting metadata: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def change_monitoring(self):
        """Change monitor module interface"""
        self.print_module_header("🔔 CHANGE MONITOR")
        
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "Add new URL to monitor",
                "Check all monitored URLs now",
                "List monitored URLs",
                "Remove URL from monitoring",
                "Start continuous monitoring",
                "Back to main menu"
            ]
        ).ask()
        
        try:
            if action == "Add new URL to monitor":
                url = questionary.text(
                    "Enter URL to monitor:",
                    validate=lambda text: text.startswith('http') or "URL must start with http:// or https://"
                ).ask()
                
                if url:
                    print(colored(f"\n📡 Fetching initial content from {url}...", "cyan"))
                    success = self.change_monitor.add_url(url)
                    if success:
                        print(colored("✅ URL added to monitoring successfully!", "magenta"))
                    else:
                        print(colored("❌ Failed to add URL", "red"))
            
            elif action == "Check all monitored URLs now":
                print(colored("\n🔍 Checking all monitored URLs for changes...\n", "cyan"))
                changes = self.change_monitor.check_all()
                
                if changes:
                    print(colored(f"\n⚠️ CHANGES DETECTED in {len(changes)} URL(s):", "red", attrs=["bold"]))
                    for change in changes:
                        print(colored(f"  • {change['url']}", "yellow"))
                else:
                    print(colored("\n✅ No changes detected", "blue"))
            
            elif action == "List monitored URLs":
                urls = self.change_monitor.list_monitored_urls()
                if urls:
                    print(colored(f"\n📋 MONITORED URLs ({len(urls)}):", "cyan", attrs=["bold"]))
                    table_data = [
                        [i+1, url[1], url[2][:16] + "...", url[3], "Yes" if url[4] else "No"]
                        for i, url in enumerate(urls)
                    ]
                    print(tabulate(
                        table_data,
                        headers=["#", "URL", "Hash", "Last Check", "Changed"],
                        tablefmt="grid"
                    ))
                else:
                    print(colored("\n📋 No URLs being monitored", "white"))
            
            elif action == "Remove URL from monitoring":
                urls = self.change_monitor.list_monitored_urls()
                if not urls:
                    print(colored("\n❌ No URLs to remove", "white"))
                else:
                    choices = [url[1] for url in urls] + ["Cancel"]
                    url_to_remove = questionary.select(
                        "Select URL to remove:",
                        choices=choices
                    ).ask()
                    
                    if url_to_remove and url_to_remove != "Cancel":
                        success = self.change_monitor.remove_url(url_to_remove)
                        if success:
                            print(colored(f"✅ Removed: {url_to_remove}", "magenta"))
            
            elif action == "Start continuous monitoring":
                interval = questionary.text(
                    "Enter check interval in seconds (default: 300):",
                    default="300"
                ).ask()
                
                try:
                    interval = int(interval)
                    print(colored(f"\n🔄 Starting continuous monitoring (Ctrl+C to stop)...", "cyan"))
                    self.change_monitor.monitor_continuously(interval)
                except ValueError:
                    print(colored("❌ Invalid interval", "red"))
                except KeyboardInterrupt:
                    print(colored("\n\n✋ Monitoring stopped", "white"))
        except Exception as e:
            logger.error(f"Error in change monitoring: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        if action != "Back to main menu":
            self.wait_for_continue()
    
    def wait_for_continue(self):
        """Wait for user to press enter and clear screen"""
        input(colored("\nPress Enter to continue...", "white"))
        self.clear_screen()
    
    def main_menu(self):
        """Display main menu and handle navigation"""
        while True:
            self.clear_screen()  # Clear screen before showing menu
            self.print_banner()
            
            choice = questionary.select(
                "Select a module:",
                choices=[
                    "🔍 Username Hunter - Search username across platforms",
                    "📧 Email OSINT - Analyze email addresses",
                    "🖼️ Image Metadata - Extract EXIF data from images",
                    "🔔 Change Monitor - Monitor websites for changes",
                    "❌ Exit"
                ]
            ).ask()
            
            if not choice or choice == "❌ Exit":
                print(colored("\n👋 Thanks for using OWL OSINT!", "cyan"))
                break
            
            try:
                if "Username Hunter" in choice:
                    self.username_search()
                elif "Email OSINT" in choice:
                    self.email_search()
                elif "Image Metadata" in choice:
                    self.image_metadata_analysis()
                elif "Change Monitor" in choice:
                    self.change_monitoring()
            except KeyboardInterrupt:
                print(colored("\n\n⚠️ Operation cancelled by user", "white"))
                self.wait_for_continue()
            except Exception as e:
                logger.error(f"Error: {e}")
                print(colored(f"\n❌ An error occurred: {e}", "red"))
                self.wait_for_continue()


def main():
    """Main entry point"""
    try:
        suite = OSINTSuite()
        suite.main_menu()
    except KeyboardInterrupt:
        print(colored("\n\n👋 Goodbye!", "cyan"))
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(colored(f"\n❌ Fatal error: {e}", "red"))
        sys.exit(1)


if __name__ == "__main__":
    main()
